--
-- PostgreSQL database dump
--

\restrict 08BbhOvw5Xsj4s0GVAZZWk18UUgUsYEnVsI9l29LMe7bD4tfWGKMNfOWJ1vZZOj

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Admission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Admission" (
    id text NOT NULL,
    "admissionNumber" text NOT NULL,
    "patientId" text NOT NULL,
    "staffId" text NOT NULL,
    "wardId" text,
    "admissionDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "dischargeDate" timestamp(3) without time zone,
    status text DEFAULT 'Admitted'::text NOT NULL,
    notes text,
    "admissionSource" text DEFAULT 'CLINIC'::text NOT NULL,
    "referringDoctor" text,
    "referralHospital" text,
    "triageLevel" text,
    "admittedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."Admission" OWNER TO postgres;

--
-- Name: AntenatalVisit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AntenatalVisit" (
    id text NOT NULL,
    "pregnancyId" text NOT NULL,
    "visitDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "gestationalWeeks" integer,
    "bloodPressure" text,
    "heartRate" integer,
    weight double precision,
    "fundalHeight" double precision,
    notes text,
    "staffId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."AntenatalVisit" OWNER TO postgres;

--
-- Name: Appointment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Appointment" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "staffId" text NOT NULL,
    "dateTime" timestamp(3) without time zone NOT NULL,
    duration integer DEFAULT 30 NOT NULL,
    status text DEFAULT 'Scheduled'::text NOT NULL,
    type text DEFAULT 'Consultation'::text NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."Appointment" OWNER TO postgres;

--
-- Name: AppointmentReminder; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppointmentReminder" (
    id text NOT NULL,
    "appointmentId" text NOT NULL,
    type text NOT NULL,
    "sentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status text NOT NULL,
    message text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."AppointmentReminder" OWNER TO postgres;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "staffId" text NOT NULL,
    action text NOT NULL,
    module text NOT NULL,
    details text,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO postgres;

--
-- Name: BillingRecord; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BillingRecord" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "invoiceNumber" text NOT NULL,
    description text NOT NULL,
    "totalAmount" double precision NOT NULL,
    status text DEFAULT 'Pending'::text NOT NULL,
    "paymentMethod" text,
    "paymentDate" timestamp(3) without time zone,
    "walletTransactionId" text,
    "isWalletPayment" boolean DEFAULT false NOT NULL,
    "walletAmountPaid" double precision,
    "cashAmountPaid" double precision,
    "paymentReference" text,
    "processedAt" timestamp(3) without time zone,
    "processedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    balance double precision NOT NULL,
    items jsonb NOT NULL,
    "paidAmount" double precision DEFAULT 0 NOT NULL,
    "receiptGenerated" boolean DEFAULT false NOT NULL,
    "receiptGeneratedAt" timestamp(3) without time zone,
    "receiptNumber" text,
    "tenantId" text NOT NULL
);


ALTER TABLE public."BillingRecord" OWNER TO postgres;

--
-- Name: Clinic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Clinic" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    location text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."Clinic" OWNER TO postgres;

--
-- Name: ClinicalNote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ClinicalNote" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "authorId" text NOT NULL,
    type text DEFAULT 'SOAP'::text NOT NULL,
    subjective text,
    objective text,
    assessment text,
    plan text,
    "fullContent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."ClinicalNote" OWNER TO postgres;

--
-- Name: Delivery; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Delivery" (
    id text NOT NULL,
    "pregnancyId" text NOT NULL,
    "deliveryDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    type text NOT NULL,
    "durationHours" double precision,
    "babyGender" text NOT NULL,
    "babyWeight" double precision,
    outcome text NOT NULL,
    notes text,
    "staffId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "babyApgar10min" integer,
    "babyApgar1min" integer,
    "babyApgar5min" integer,
    "babyHeadCircumference" double precision,
    "babyLength" double precision,
    "babyNotes" text,
    complications text,
    "estimatedBloodLoss" double precision,
    "maternalCondition" text,
    "perinealCondition" text,
    "placentaDelivery" text,
    "tenantId" text NOT NULL
);


ALTER TABLE public."Delivery" OWNER TO postgres;

--
-- Name: Department; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Department" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "managerId" text,
    location text,
    "costCenter" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."Department" OWNER TO postgres;

--
-- Name: Hospital; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Hospital" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    code text NOT NULL,
    email text,
    phone text,
    address text,
    city text,
    state text,
    country text DEFAULT 'Nigeria'::text NOT NULL,
    "logoUrl" text,
    "primaryColor" text DEFAULT '#0f3460'::text NOT NULL,
    "secondaryColor" text DEFAULT '#1a4a7a'::text NOT NULL,
    plan text DEFAULT 'trial'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    "trialEndsAt" timestamp(3) without time zone,
    "subscriptionEndsAt" timestamp(3) without time zone,
    "maxStaff" integer DEFAULT 50 NOT NULL,
    "maxPatients" integer DEFAULT 1000 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Hospital" OWNER TO postgres;

--
-- Name: HospitalSettings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."HospitalSettings" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "hospitalId" text NOT NULL,
    "registrationFee" double precision DEFAULT 2000 NOT NULL,
    "cardFee" double precision DEFAULT 1000 NOT NULL,
    "consultationFee" double precision DEFAULT 5000 NOT NULL,
    "nhisMultiplier" double precision DEFAULT 0.1 NOT NULL,
    "retainerMultiplier" double precision DEFAULT 2.0 NOT NULL,
    "autoArchiveHours" integer DEFAULT 24 NOT NULL,
    "appointmentDuration" integer DEFAULT 30 NOT NULL,
    "enablePatientPortal" boolean DEFAULT true NOT NULL,
    "enableKioskMode" boolean DEFAULT true NOT NULL,
    "smsEnabled" boolean DEFAULT false NOT NULL,
    "emailEnabled" boolean DEFAULT false NOT NULL,
    "smsSenderId" text,
    "emailSenderName" text,
    currency text DEFAULT 'NGN'::text NOT NULL,
    "currencySymbol" text DEFAULT '₦'::text NOT NULL,
    timezone text DEFAULT 'Africa/Lagos'::text NOT NULL,
    "dateFormat" text DEFAULT 'DD/MM/YYYY'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."HospitalSettings" OWNER TO postgres;

--
-- Name: ImagingOrder; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ImagingOrder" (
    id text NOT NULL,
    "orderNumber" text NOT NULL,
    "patientId" text NOT NULL,
    "imagingType" text NOT NULL,
    "bodyPart" text NOT NULL,
    priority text DEFAULT 'Routine'::text NOT NULL,
    "clinicalHistory" text,
    "clinicalQuestion" text,
    "orderingStaffId" text NOT NULL,
    status text DEFAULT 'Ordered'::text NOT NULL,
    result text,
    "resultDate" timestamp(3) without time zone,
    report text,
    "imagesUrl" text,
    images text,
    "imageCount" integer DEFAULT 0 NOT NULL,
    "hasImages" boolean DEFAULT false NOT NULL,
    "radiologistId" text,
    "billingRecordId" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."ImagingOrder" OWNER TO postgres;

--
-- Name: ImagingResult; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ImagingResult" (
    id text NOT NULL,
    "imagingOrderId" text NOT NULL,
    findings text NOT NULL,
    impression text NOT NULL,
    recommendations text,
    severity text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."ImagingResult" OWNER TO postgres;

--
-- Name: KioskSession; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."KioskSession" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "sessionToken" text NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endedAt" timestamp(3) without time zone,
    status text DEFAULT 'active'::text NOT NULL,
    "deviceInfo" text,
    "ipAddress" text,
    "tenantId" text NOT NULL
);


ALTER TABLE public."KioskSession" OWNER TO postgres;

--
-- Name: LabOrder; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LabOrder" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "orderingStaffId" text NOT NULL,
    "labStaffId" text,
    "testName" text NOT NULL,
    "testType" text NOT NULL,
    priority text DEFAULT 'Routine'::text NOT NULL,
    status text DEFAULT 'Ordered'::text NOT NULL,
    result text,
    "resultDate" timestamp(3) without time zone,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    validated boolean DEFAULT false NOT NULL,
    "validatedAt" timestamp(3) without time zone,
    "validatedBy" text,
    "tenantId" text NOT NULL
);


ALTER TABLE public."LabOrder" OWNER TO postgres;

--
-- Name: Medication; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Medication" (
    id text NOT NULL,
    name text NOT NULL,
    "genericName" text,
    category text NOT NULL,
    supplier text,
    "unitPrice" double precision NOT NULL,
    "stockQuantity" integer NOT NULL,
    "reorderLevel" integer NOT NULL,
    "expiryDate" timestamp(3) without time zone NOT NULL,
    "batchNumber" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."Medication" OWNER TO postgres;

--
-- Name: MedicationTransaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MedicationTransaction" (
    id text NOT NULL,
    "medicationId" text NOT NULL,
    "transactionType" text NOT NULL,
    quantity integer NOT NULL,
    "unitPrice" double precision NOT NULL,
    "totalPrice" double precision DEFAULT 0 NOT NULL,
    note text,
    "staffId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    reference text,
    "patientId" text,
    "tenantId" text NOT NULL
);


ALTER TABLE public."MedicationTransaction" OWNER TO postgres;

--
-- Name: NHISAuthorization; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."NHISAuthorization" (
    id text NOT NULL,
    "authorizationNumber" text NOT NULL,
    "patientId" text NOT NULL,
    "prescriptionId" text,
    medications text NOT NULL,
    "totalAmount" double precision NOT NULL,
    "nhisAmount" double precision NOT NULL,
    "patientAmount" double precision NOT NULL,
    status text DEFAULT 'Pending'::text NOT NULL,
    "requestedBy" text NOT NULL,
    "approvedBy" text,
    "requestDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "approvalDate" timestamp(3) without time zone,
    "expiryDate" timestamp(3) without time zone,
    "denialReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."NHISAuthorization" OWNER TO postgres;

--
-- Name: NHISClaim; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."NHISClaim" (
    id text NOT NULL,
    "claimNumber" text NOT NULL,
    "patientId" text NOT NULL,
    "authorizationId" text,
    "prescriptionId" text,
    "totalAmount" double precision NOT NULL,
    "nhisAmount" double precision NOT NULL,
    "patientAmount" double precision NOT NULL,
    "copayCollected" double precision DEFAULT 0 NOT NULL,
    status text DEFAULT 'Draft'::text NOT NULL,
    "submissionDate" timestamp(3) without time zone,
    "approvalDate" timestamp(3) without time zone,
    "paymentDate" timestamp(3) without time zone,
    "submittedBy" text NOT NULL,
    "approvedBy" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."NHISClaim" OWNER TO postgres;

--
-- Name: NHISDrugFormulary; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."NHISDrugFormulary" (
    id text NOT NULL,
    "medicationId" text NOT NULL,
    "nhisCode" text NOT NULL,
    "nhisName" text,
    "formularyStatus" text DEFAULT 'Active'::text NOT NULL,
    "coverageType" text DEFAULT 'Full'::text NOT NULL,
    "coveragePercentage" double precision DEFAULT 90 NOT NULL,
    "patientCopayPercent" double precision DEFAULT 10 NOT NULL,
    "maxQuantityPerPrescription" integer,
    "maxRefills" integer DEFAULT 3 NOT NULL,
    "validityPeriod" integer DEFAULT 30 NOT NULL,
    "requiresPriorAuth" boolean DEFAULT false NOT NULL,
    "requiresDiagnosis" boolean DEFAULT false NOT NULL,
    "allowedDiagnosis" text,
    "ageRestriction" text,
    "genderRestriction" text,
    "nhisPrice" double precision NOT NULL,
    "patientPrice" double precision NOT NULL,
    "standardPrice" double precision NOT NULL,
    "effectiveDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiryDate" timestamp(3) without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."NHISDrugFormulary" OWNER TO postgres;

--
-- Name: NHISDrugPrice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."NHISDrugPrice" (
    id text NOT NULL,
    "medicationId" text NOT NULL,
    "nhisCode" text NOT NULL,
    "nhisName" text,
    "standardPrice" double precision NOT NULL,
    "nhisPrice" double precision NOT NULL,
    "patientCopay" double precision NOT NULL,
    "nhisCoverage" double precision NOT NULL,
    "maxQuantity" integer,
    "refillLimit" integer DEFAULT 3 NOT NULL,
    "validityPeriod" integer DEFAULT 30 NOT NULL,
    "drugClass" text,
    "requiresPriorAuth" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "effectiveDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiryDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."NHISDrugPrice" OWNER TO postgres;

--
-- Name: PartialPayment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PartialPayment" (
    id text NOT NULL,
    "paymentPlanId" text NOT NULL,
    amount double precision NOT NULL,
    "paymentMethod" text NOT NULL,
    reference text,
    notes text,
    "processedBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."PartialPayment" OWNER TO postgres;

--
-- Name: Patient; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Patient" (
    id text NOT NULL,
    "hospitalId" text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    "dateOfBirth" timestamp(3) without time zone NOT NULL,
    gender text NOT NULL,
    phone text,
    email text,
    address text,
    "emergencyContact" text,
    allergies text,
    "nextOfKinName" text,
    "nextOfKinPhone" text,
    "nextOfKinRelationship" text,
    "patientCategory" text DEFAULT 'FPP'::text NOT NULL,
    "insuranceProvider" text,
    "insuranceId" text,
    "corporateCompany" text,
    password text,
    "portalAccess" boolean DEFAULT false NOT NULL,
    "lastLogin" timestamp(3) without time zone,
    "isVerified" boolean DEFAULT false NOT NULL,
    "pinCode" text,
    "mustChangePassword" boolean DEFAULT false NOT NULL,
    "pinAttempts" integer DEFAULT 0 NOT NULL,
    "passwordAttempts" integer DEFAULT 0 NOT NULL,
    "lockedUntil" timestamp(3) without time zone,
    "lastPinChange" timestamp(3) without time zone,
    "lastPasswordChange" timestamp(3) without time zone,
    "isArchived" boolean DEFAULT false NOT NULL,
    "archivedAt" timestamp(3) without time zone,
    "archivedReason" text,
    "archivedBy" text,
    "autoArchived" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "walletId" text,
    "accessCount" integer DEFAULT 0 NOT NULL,
    "activationRequestedAt" timestamp(3) without time zone,
    "archiveScheduledAt" timestamp(3) without time zone,
    "isActiveForModule" boolean DEFAULT true NOT NULL,
    "lastAccessedAt" timestamp(3) without time zone,
    "autoArchiveAt" timestamp(3) without time zone,
    "dischargeNotes" text,
    "dischargeType" text,
    "dischargedAt" timestamp(3) without time zone,
    "dischargedBy" text,
    "fileStatus" text DEFAULT 'ACTIVE'::text NOT NULL,
    "isDischarged" boolean DEFAULT false NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."Patient" OWNER TO postgres;

--
-- Name: PatientHistoryRecord; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PatientHistoryRecord" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "encounterDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "doctorName" text NOT NULL,
    "encounterType" text NOT NULL,
    diagnosis text NOT NULL,
    "icd10Code" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."PatientHistoryRecord" OWNER TO postgres;

--
-- Name: PatientJourney; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PatientJourney" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "destinationType" text DEFAULT 'CLINIC'::text NOT NULL,
    "clinicId" text,
    "wardId" text,
    "registeredById" text NOT NULL,
    status text DEFAULT 'REGISTERED'::text NOT NULL,
    "cardGeneratedAt" timestamp(3) without time zone,
    "sentToDestinationAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "archivedAt" timestamp(3) without time zone,
    "billingRecordId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "cardFeeBilled" boolean DEFAULT false NOT NULL,
    "cardFeePaid" boolean DEFAULT false NOT NULL,
    "cardFeeRecordId" text,
    "consultationFeeBilled" boolean DEFAULT false NOT NULL,
    "consultationFeePaid" boolean DEFAULT false NOT NULL,
    "consultationFeeRecordId" text,
    "registrationFeeBilled" boolean DEFAULT false NOT NULL,
    "registrationFeePaid" boolean DEFAULT false NOT NULL,
    "registrationFeeRecordId" text,
    "activatedAt" timestamp(3) without time zone,
    "activatedBy" text,
    "activationRequested" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."PatientJourney" OWNER TO postgres;

--
-- Name: PatientMessage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PatientMessage" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "staffId" text NOT NULL,
    subject text NOT NULL,
    message text NOT NULL,
    "isRead" boolean DEFAULT false NOT NULL,
    "isFromPatient" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."PatientMessage" OWNER TO postgres;

--
-- Name: PatientQueue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PatientQueue" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "checkInTime" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "checkInMethod" text DEFAULT 'manual_entry'::text NOT NULL,
    status text DEFAULT 'waiting'::text NOT NULL,
    priority text DEFAULT 'normal'::text NOT NULL,
    "appointmentId" text,
    "destinationType" text DEFAULT 'CLINIC'::text NOT NULL,
    "clinicId" text,
    "wardId" text,
    "assignedTo" text,
    "calledTime" timestamp(3) without time zone,
    "startTime" timestamp(3) without time zone,
    "endTime" timestamp(3) without time zone,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."PatientQueue" OWNER TO postgres;

--
-- Name: PatientTransfer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PatientTransfer" (
    id text NOT NULL,
    "transferNumber" text NOT NULL,
    "patientId" text NOT NULL,
    "fromLocationType" text NOT NULL,
    "fromClinicId" text,
    "fromWardId" text,
    "toLocationType" text NOT NULL,
    "toClinicId" text,
    "toWardId" text,
    reason text NOT NULL,
    priority text DEFAULT 'Normal'::text NOT NULL,
    "transportType" text,
    "requestedBy" text NOT NULL,
    "approvedBy" text,
    status text DEFAULT 'Pending'::text NOT NULL,
    "requestedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "approvedAt" timestamp(3) without time zone,
    "departedAt" timestamp(3) without time zone,
    "arrivedAt" timestamp(3) without time zone,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."PatientTransfer" OWNER TO postgres;

--
-- Name: PatientWallet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PatientWallet" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    balance double precision DEFAULT 0 NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    "lastTransactionAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."PatientWallet" OWNER TO postgres;

--
-- Name: PaymentPlan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PaymentPlan" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "billingRecordId" text NOT NULL,
    "totalAmount" double precision NOT NULL,
    "paidAmount" double precision DEFAULT 0 NOT NULL,
    balance double precision NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    installments integer DEFAULT 1 NOT NULL,
    "installmentAmount" double precision NOT NULL,
    frequency text NOT NULL,
    "startDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endDate" timestamp(3) without time zone,
    "nextPaymentDate" timestamp(3) without time zone,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."PaymentPlan" OWNER TO postgres;

--
-- Name: PharmacyBranch; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PharmacyBranch" (
    id text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    location text,
    phone text,
    email text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."PharmacyBranch" OWNER TO postgres;

--
-- Name: PharmacyStaff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PharmacyStaff" (
    id text NOT NULL,
    "pharmacyId" text NOT NULL,
    "staffId" text NOT NULL,
    role text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."PharmacyStaff" OWNER TO postgres;

--
-- Name: PharmacyTransaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PharmacyTransaction" (
    id text NOT NULL,
    "transactionNumber" text NOT NULL,
    "pharmacyId" text NOT NULL,
    "medicationId" text NOT NULL,
    "transactionType" text NOT NULL,
    quantity integer NOT NULL,
    "unitPrice" double precision NOT NULL,
    "totalPrice" double precision NOT NULL,
    reference text,
    note text,
    "staffId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."PharmacyTransaction" OWNER TO postgres;

--
-- Name: Pregnancy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Pregnancy" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "expectedDelivery" timestamp(3) without time zone NOT NULL,
    gravida integer,
    para integer,
    "lastMenstrualPeriod" timestamp(3) without time zone,
    "estimatedDueDate" timestamp(3) without time zone,
    "riskLevel" text,
    status text DEFAULT 'Active'::text NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    contractions text,
    "deliveryDate" timestamp(3) without time zone,
    dilation double precision,
    effacement double precision,
    "laborNotes" text,
    "laborStartTime" timestamp(3) without time zone,
    "tenantId" text NOT NULL
);


ALTER TABLE public."Pregnancy" OWNER TO postgres;

--
-- Name: Prescription; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Prescription" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "prescribingStaffId" text NOT NULL,
    "dispensingStaffId" text,
    medication text NOT NULL,
    dosage text NOT NULL,
    frequency text NOT NULL,
    duration text NOT NULL,
    instructions text,
    "pharmacistNotes" text,
    "dispensedAt" timestamp(3) without time zone,
    "rejectionReason" text,
    status text DEFAULT 'Prescribed'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."Prescription" OWNER TO postgres;

--
-- Name: ROIRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ROIRequest" (
    id text NOT NULL,
    "requestorName" text NOT NULL,
    "patientName" text NOT NULL,
    "requestDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "requestType" text NOT NULL,
    status text DEFAULT 'Pending'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."ROIRequest" OWNER TO postgres;

--
-- Name: RolePermission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RolePermission" (
    id text NOT NULL,
    role text NOT NULL,
    dashboard boolean DEFAULT false NOT NULL,
    patients boolean DEFAULT false NOT NULL,
    staff boolean DEFAULT false NOT NULL,
    appointments boolean DEFAULT false NOT NULL,
    prescriptions boolean DEFAULT false NOT NULL,
    "labOrders" boolean DEFAULT false NOT NULL,
    billing boolean DEFAULT false NOT NULL,
    pharmacy boolean DEFAULT false NOT NULL,
    "pharmacyDashboard" boolean DEFAULT false NOT NULL,
    "pharmacyInventory" boolean DEFAULT false NOT NULL,
    "nhisManagement" boolean DEFAULT false NOT NULL,
    "nhisAuthorizations" boolean DEFAULT false NOT NULL,
    "pharmacyStock" boolean DEFAULT false NOT NULL,
    "pharmacyTransactions" boolean DEFAULT false NOT NULL,
    "pharmacyBranches" boolean DEFAULT false NOT NULL,
    clinics boolean DEFAULT false NOT NULL,
    wards boolean DEFAULT false NOT NULL,
    pricing boolean DEFAULT false NOT NULL,
    "billingOfficer" boolean DEFAULT false NOT NULL,
    wallet boolean DEFAULT false NOT NULL,
    "patientIntake" boolean DEFAULT false NOT NULL,
    admissions boolean DEFAULT false NOT NULL,
    "patientHistory" boolean DEFAULT false NOT NULL,
    "roiRequests" boolean DEFAULT false NOT NULL,
    "nurseDashboard" boolean DEFAULT false NOT NULL,
    "doctorDashboard" boolean DEFAULT false NOT NULL,
    antenatal boolean DEFAULT false NOT NULL,
    "archivedPatients" boolean DEFAULT false NOT NULL,
    "archivedPatientsView" boolean DEFAULT false NOT NULL,
    "queueManagement" boolean DEFAULT false NOT NULL,
    "doctorQueue" boolean DEFAULT false NOT NULL,
    "hrDashboard" boolean DEFAULT false NOT NULL,
    "hrEmployees" boolean DEFAULT false NOT NULL,
    "hrDepartments" boolean DEFAULT false NOT NULL,
    "hrLeaves" boolean DEFAULT false NOT NULL,
    "hrAttendance" boolean DEFAULT false NOT NULL,
    "hrPerformance" boolean DEFAULT false NOT NULL,
    "hrTrainings" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    dental boolean DEFAULT false NOT NULL,
    immunizations boolean DEFAULT false NOT NULL,
    "laborAndDelivery" boolean DEFAULT false NOT NULL,
    optometry boolean DEFAULT false NOT NULL,
    "patientPortal" boolean DEFAULT false NOT NULL,
    "portalSetup" boolean DEFAULT false NOT NULL,
    radiology boolean DEFAULT false NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."RolePermission" OWNER TO postgres;

--
-- Name: ServiceConfiguration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ServiceConfiguration" (
    id text NOT NULL,
    "serviceType" text NOT NULL,
    name text NOT NULL,
    description text,
    "baseAmount" double precision NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "corporateAmount" double precision,
    "nhisAmount" double precision,
    "tenantId" text NOT NULL
);


ALTER TABLE public."ServiceConfiguration" OWNER TO postgres;

--
-- Name: ServicePrice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ServicePrice" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    amount double precision NOT NULL,
    "clinicId" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."ServicePrice" OWNER TO postgres;

--
-- Name: ServicePricing; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ServicePricing" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    category text DEFAULT 'FPP'::text NOT NULL,
    "basePrice" double precision DEFAULT 0 NOT NULL,
    "nhisPrice" double precision DEFAULT 0 NOT NULL,
    "corporatePrice" double precision DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."ServicePricing" OWNER TO postgres;

--
-- Name: Staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Staff" (
    id text NOT NULL,
    "employeeId" text NOT NULL,
    username text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    email text NOT NULL,
    role text NOT NULL,
    password text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    manager_id text,
    "dateOfBirth" timestamp(3) without time zone,
    gender text,
    phone text,
    address text,
    "emergencyContact" text,
    "employmentType" text,
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    salary double precision,
    "bankName" text,
    "bankAccount" text,
    "bankBranch" text,
    "taxId" text,
    "nationalId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "departmentId" text,
    "tenantId" text NOT NULL
);


ALTER TABLE public."Staff" OWNER TO postgres;

--
-- Name: StaffClinic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."StaffClinic" (
    "staffId" text NOT NULL,
    "clinicId" text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."StaffClinic" OWNER TO postgres;

--
-- Name: StaffWard; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."StaffWard" (
    "staffId" text NOT NULL,
    "wardId" text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."StaffWard" OWNER TO postgres;

--
-- Name: VitalSign; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."VitalSign" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "nurseId" text NOT NULL,
    "recordedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "bloodPressureSystolic" integer,
    "bloodPressureDiastolic" integer,
    "heartRate" integer,
    temperature double precision,
    "respiratoryRate" integer,
    "oxygenSaturation" integer,
    weight double precision,
    height double precision,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."VitalSign" OWNER TO postgres;

--
-- Name: WalletTransaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WalletTransaction" (
    id text NOT NULL,
    "walletId" text NOT NULL,
    "transactionType" text NOT NULL,
    amount double precision NOT NULL,
    "balanceBefore" double precision NOT NULL,
    "balanceAfter" double precision NOT NULL,
    description text NOT NULL,
    reference text NOT NULL,
    status text DEFAULT 'Completed'::text NOT NULL,
    "billingRecordId" text,
    category text,
    "serviceId" text,
    "serviceType" text,
    "paymentReference" text,
    "processedAt" timestamp(3) without time zone,
    "processedBy" text,
    "paidToStaffId" text,
    "paymentMethod" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."WalletTransaction" OWNER TO postgres;

--
-- Name: Ward; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Ward" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    capacity integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public."Ward" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: attendance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attendance (
    id text NOT NULL,
    staff_id text NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    clock_in timestamp(3) without time zone,
    clock_out timestamp(3) without time zone,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.attendance OWNER TO postgres;

--
-- Name: dental_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dental_records (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "examinationDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "teethNumber" text,
    condition text NOT NULL,
    "treatmentPlan" text,
    procedure text,
    notes text,
    "staffId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.dental_records OWNER TO postgres;

--
-- Name: immunizations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.immunizations (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "vaccineName" text NOT NULL,
    "doseNumber" integer DEFAULT 1 NOT NULL,
    "administrationDate" timestamp(3) without time zone NOT NULL,
    route text DEFAULT 'IM'::text NOT NULL,
    site text DEFAULT 'Deltoid'::text NOT NULL,
    "batchNumber" text,
    "expiryDate" timestamp(3) without time zone,
    "nextDueDate" timestamp(3) without time zone,
    "administeredBy" text NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.immunizations OWNER TO postgres;

--
-- Name: leave_notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.leave_notifications (
    id text NOT NULL,
    leave_request_id text,
    staff_id text,
    notification_type text NOT NULL,
    message text NOT NULL,
    scheduled_date timestamp(3) without time zone,
    sent_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP,
    status text DEFAULT 'PENDING'::text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    read_at timestamp(3) without time zone,
    is_global boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.leave_notifications OWNER TO postgres;

--
-- Name: leave_policies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.leave_policies (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    default_annual_days double precision DEFAULT 21 NOT NULL,
    default_sick_days double precision DEFAULT 10 NOT NULL,
    default_study_days double precision DEFAULT 5 NOT NULL,
    default_maternity_days double precision DEFAULT 90 NOT NULL,
    default_paternity_days double precision DEFAULT 14 NOT NULL,
    max_carry_over_days double precision DEFAULT 5 NOT NULL,
    carry_over_expiry integer,
    leave_year_start_month integer DEFAULT 1 NOT NULL,
    leave_year_end_month integer DEFAULT 12 NOT NULL,
    pro_rata_enabled boolean DEFAULT true NOT NULL,
    reminder_days integer DEFAULT 30 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.leave_policies OWNER TO postgres;

--
-- Name: leave_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.leave_requests (
    id text NOT NULL,
    staff_id text NOT NULL,
    leave_type text NOT NULL,
    start_date timestamp(3) without time zone NOT NULL,
    end_date timestamp(3) without time zone NOT NULL,
    days integer NOT NULL,
    reason text,
    contact_during_leave text,
    substitute_id text,
    status text DEFAULT 'Pending'::text NOT NULL,
    approved_by_id text,
    approved_at timestamp(3) without time zone,
    comments text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    leave_usage_id text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.leave_requests OWNER TO postgres;

--
-- Name: leave_usages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.leave_usages (
    id text NOT NULL,
    staff_id text NOT NULL,
    leave_request_id text,
    entitlement_id text,
    leave_type text NOT NULL,
    days_used double precision NOT NULL,
    start_date timestamp(3) without time zone NOT NULL,
    end_date timestamp(3) without time zone NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    approved_by_id text,
    approved_at timestamp(3) without time zone,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.leave_usages OWNER TO postgres;

--
-- Name: optometry_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.optometry_records (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "examinationDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "visualAcuityRight" text,
    "visualAcuityLeft" text,
    "intraocularPressureRight" double precision,
    "intraocularPressureLeft" double precision,
    "refractionRight" text,
    "refractionLeft" text,
    diagnosis text,
    treatment text,
    prescription text,
    notes text,
    "staffId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.optometry_records OWNER TO postgres;

--
-- Name: patient_notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient_notifications (
    id text NOT NULL,
    "patientId" text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    type text NOT NULL,
    "isRead" boolean DEFAULT false NOT NULL,
    link text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.patient_notifications OWNER TO postgres;

--
-- Name: performance_reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.performance_reviews (
    id text NOT NULL,
    staff_id text NOT NULL,
    reviewer_id text NOT NULL,
    review_date timestamp(3) without time zone NOT NULL,
    period_start timestamp(3) without time zone,
    period_end timestamp(3) without time zone,
    rating integer,
    strengths text,
    weaknesses text,
    goals text,
    recommendations text,
    overall_comments text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.performance_reviews OWNER TO postgres;

--
-- Name: staff_leave_entitlements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff_leave_entitlements (
    id text NOT NULL,
    staff_id text NOT NULL,
    year integer NOT NULL,
    annual_leave_days double precision DEFAULT 21 NOT NULL,
    sick_leave_days double precision DEFAULT 10 NOT NULL,
    study_leave_days double precision DEFAULT 5 NOT NULL,
    maternity_leave_days double precision DEFAULT 90 NOT NULL,
    paternity_leave_days double precision DEFAULT 14 NOT NULL,
    unpaid_leave_days double precision DEFAULT 0 NOT NULL,
    carried_over_days double precision DEFAULT 0 NOT NULL,
    total_available_days double precision NOT NULL,
    used_annual_days double precision DEFAULT 0 NOT NULL,
    used_sick_days double precision DEFAULT 0 NOT NULL,
    used_study_days double precision DEFAULT 0 NOT NULL,
    used_maternity_days double precision DEFAULT 0 NOT NULL,
    used_paternity_days double precision DEFAULT 0 NOT NULL,
    used_unpaid_days double precision DEFAULT 0 NOT NULL,
    remaining_annual_days double precision NOT NULL,
    remaining_sick_days double precision NOT NULL,
    remaining_study_days double precision NOT NULL,
    remaining_maternity_days double precision NOT NULL,
    remaining_paternity_days double precision NOT NULL,
    remaining_unpaid_days double precision NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_locked boolean DEFAULT false NOT NULL,
    created_by text,
    updated_by text,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.staff_leave_entitlements OWNER TO postgres;

--
-- Name: staff_trainings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff_trainings (
    staff_id text NOT NULL,
    training_id text NOT NULL,
    enrollment_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completion_date timestamp(3) without time zone,
    completion_status text DEFAULT 'Enrolled'::text NOT NULL,
    certificate_issued boolean DEFAULT false NOT NULL,
    score integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.staff_trainings OWNER TO postgres;

--
-- Name: trainings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trainings (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    provider text,
    start_date timestamp(3) without time zone NOT NULL,
    end_date timestamp(3) without time zone,
    cost double precision,
    location text,
    max_participants integer,
    certificate_provided boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.trainings OWNER TO postgres;

--
-- Data for Name: Admission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Admission" (id, "admissionNumber", "patientId", "staffId", "wardId", "admissionDate", "dischargeDate", status, notes, "admissionSource", "referringDoctor", "referralHospital", "triageLevel", "admittedBy", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: AntenatalVisit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AntenatalVisit" (id, "pregnancyId", "visitDate", "gestationalWeeks", "bloodPressure", "heartRate", weight, "fundalHeight", notes, "staffId", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: Appointment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Appointment" (id, "patientId", "staffId", "dateTime", duration, status, type, notes, "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: AppointmentReminder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppointmentReminder" (id, "appointmentId", type, "sentAt", status, message, "createdAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AuditLog" (id, "staffId", action, module, details, "ipAddress", "createdAt", "tenantId") FROM stdin;
cmtzxkgip0000n4lg8epiop61	cmtzwkwan000e9clg98g591dx	LOGIN	Auth	Staff admin logged in	::ffff:127.0.0.1	2026-09-13 14:49:55.873	default-hospital-id
cmtzy1zg0000188lgsmlyjkyb	cmtzwkwan000e9clg98g591dx	CREATE_STAFF	Staff	Created staff adeboye-daniel as Admin	\N	2026-09-13 15:03:33.552	default-hospital-id
cmtzyeriz0000r0lg72odymo7	cmtzy1zet000088lgjpdh9g3t	LOGIN	Auth	Staff adeboye-daniel logged in	::1	2026-09-13 15:13:29.819	default-hospital-id
cmtzyx0lo0000v8lgtwn2zyum	cmtzy1zet000088lgjpdh9g3t	LOGIN	Auth	Staff adeboye-daniel logged in	::1	2026-09-13 15:27:41.39	default-hospital-id
\.


--
-- Data for Name: BillingRecord; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."BillingRecord" (id, "patientId", "invoiceNumber", description, "totalAmount", status, "paymentMethod", "paymentDate", "walletTransactionId", "isWalletPayment", "walletAmountPaid", "cashAmountPaid", "paymentReference", "processedAt", "processedBy", "createdAt", "updatedAt", balance, items, "paidAmount", "receiptGenerated", "receiptGeneratedAt", "receiptNumber", "tenantId") FROM stdin;
\.


--
-- Data for Name: Clinic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Clinic" (id, name, description, location, "isActive", "createdAt", "updatedAt", "tenantId") FROM stdin;
cmtzwkuow00049clg9lk7fqhu	General Outpatient	General outpatient services	Ground Floor, Block A	t	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	default-hospital-id
cmtzwkur100059clgp4q7l4yb	Paediatrics	Paediatric care for children	First Floor, Block B	t	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	default-hospital-id
cmtzwkure00069clgtww1dyqs	Obstetrics & Gynaecology	Women's health and maternity	Second Floor, Block A	t	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	default-hospital-id
cmtzwkus500079clg665obtwn	Internal Medicine	Adult medical care	Ground Floor, Block C	t	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	default-hospital-id
cmtzwkusd00089clg9c0bmahx	Surgery	Surgical consultations	First Floor, Block C	t	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv3xs0009n4lga0aq6glq	Postnatal Clinic	Post-delivery care services	Women's Wing, Ground Floor	t	2026-09-13 15:26:12.4	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv3yh000an4lgpfjjav0f	Family Planning Clinic	Family planning and reproductive health	Women's Wing, 1st Floor	t	2026-09-13 15:26:12.425	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv3yk000bn4lgm7ng323b	Nutrition Clinic	Nutritional counseling and support	Main Building, Ground Floor	t	2026-09-13 15:26:12.429	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv3yo000cn4lg0bh3vuaf	Diabetes/Endocrinology Clinic	Diabetes and endocrine disorders	Main Building, 1st Floor	t	2026-09-13 15:26:12.432	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv3ys000dn4lgwtpwym99	Cardiology Clinic	Heart and cardiovascular services	Main Building, 2nd Floor	t	2026-09-13 15:26:12.436	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv3yv000en4lgpj1l20go	Neurology Clinic	Brain and nervous system services	Main Building, 2nd Floor	t	2026-09-13 15:26:12.439	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv3yz000fn4lgj8c4bf1k	Oncology Clinic	Cancer care services	Oncology Wing, Ground Floor	t	2026-09-13 15:26:12.443	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv3z2000gn4lgl3hinn20	Renal Clinic	Kidney care services	Renal Wing, Ground Floor	t	2026-09-13 15:26:12.446	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv3z5000hn4lg3fj3rrp9	Respiratory Clinic	Lung and respiratory services	Main Building, 1st Floor	t	2026-09-13 15:26:12.449	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv3z8000in4lg8rdlrvd5	Gastroenterology Clinic	Digestive system services	Main Building, 1st Floor	t	2026-09-13 15:26:12.452	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv3zb000jn4lgyizysfoy	Rheumatology Clinic	Autoimmune and joint disorders	Main Building, 2nd Floor	t	2026-09-13 15:26:12.455	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv3zf000kn4lgly0nsbm1	Haematology Clinic	Blood disorders services	Main Building, 1st Floor	t	2026-09-13 15:26:12.459	2026-09-13 15:26:11.296	default-hospital-id
\.


--
-- Data for Name: ClinicalNote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ClinicalNote" (id, "patientId", "authorId", type, subjective, objective, assessment, plan, "fullContent", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: Delivery; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Delivery" (id, "pregnancyId", "deliveryDate", type, "durationHours", "babyGender", "babyWeight", outcome, notes, "staffId", "createdAt", "updatedAt", "babyApgar10min", "babyApgar1min", "babyApgar5min", "babyHeadCircumference", "babyLength", "babyNotes", complications, "estimatedBloodLoss", "maternalCondition", "perinealCondition", "placentaDelivery", "tenantId") FROM stdin;
\.


--
-- Data for Name: Department; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Department" (id, name, description, "managerId", location, "costCenter", "isActive", "createdAt", "updatedAt", "tenantId") FROM stdin;
cmtzyv4ld0057n4lgj8ucp4u3	Internal Medicine	General internal medicine	\N	Main Building, 1st Floor	IM-001	t	2026-09-13 15:26:13.249	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4lv0058n4lg0xjkdv5a	Surgery	Surgical services	\N	Surgical Wing	SUR-002	t	2026-09-13 15:26:13.267	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4m00059n4lgo4rfl102	Paediatrics	Child health services	\N	Children's Wing	PED-003	t	2026-09-13 15:26:13.272	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4m3005an4lger34c8ot	Obstetrics & Gynaecology	Women's health and maternity	\N	Women's Wing	OBG-004	t	2026-09-13 15:26:13.275	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4m6005bn4lgpwkwufnq	Orthopaedics	Bone and joint services	\N	Orthopaedic Wing	ORT-005	t	2026-09-13 15:26:13.278	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4m9005cn4lgbc1x69sr	Ophthalmology	Eye care services	\N	Main Building, 2nd Floor	OPH-006	t	2026-09-13 15:26:13.281	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4mc005dn4lgwiruu5zn	ENT	Ear, nose, and throat services	\N	Main Building, 2nd Floor	ENT-007	t	2026-09-13 15:26:13.284	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4mf005en4lg2oqxw0v1	Dermatology	Skin care services	\N	Main Building, 3rd Floor	DER-008	t	2026-09-13 15:26:13.287	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4mk005fn4lgwwuz966v	Psychiatry	Mental health services	\N	Psychiatric Wing	PSY-009	t	2026-09-13 15:26:13.292	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4mm005gn4lgfr6cdimy	Dentistry	Dental care services	\N	Dental Wing	DEN-010	t	2026-09-13 15:26:13.294	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4mo005hn4lgqn065izb	Pharmacy	Pharmacy services	\N	Pharmacy Wing	PHA-011	t	2026-09-13 15:26:13.296	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4mr005in4lghy70j2af	Laboratory	Clinical laboratory services	\N	Lab Wing	LAB-012	t	2026-09-13 15:26:13.299	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4mu005jn4lg9ffxg3ck	Radiology	Imaging and radiology services	\N	Radiology Wing	RAD-013	t	2026-09-13 15:26:13.302	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4mx005kn4lgpbjmvo0u	Physiotherapy	Physical therapy services	\N	Rehabilitation Wing	PHY-014	t	2026-09-13 15:26:13.305	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4mz005ln4lg5gw4s5mn	Nutrition & Dietetics	Clinical nutrition services	\N	Main Building, Ground Floor	NUT-015	t	2026-09-13 15:26:13.307	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4n1005mn4lgwtcmu2pk	Administration	Hospital administration	\N	Admin Wing	ADM-016	t	2026-09-13 15:26:13.309	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4n3005nn4lgj145h8cd	Human Resources	Staff management and recruitment	\N	Admin Wing	HR-017	t	2026-09-13 15:26:13.311	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4n5005on4lg5mk9nrtf	Finance	Financial management	\N	Admin Wing	FIN-018	t	2026-09-13 15:26:13.313	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4n7005pn4lghxz2ad3t	Accounts	Accounting services	\N	Admin Wing	ACC-019	t	2026-09-13 15:26:13.315	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4n9005qn4lgz8tbdkj0	Medical Records	Medical records management	\N	Records Wing	MR-020	t	2026-09-13 15:26:13.317	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4nb005rn4lg5gp0naqx	Billing	Billing and insurance services	\N	Admin Wing	BIL-021	t	2026-09-13 15:26:13.319	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4nd005sn4lgekfrs78o	ICT	Information technology services	\N	IT Wing	ICT-022	t	2026-09-13 15:26:13.322	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4ng005tn4lgn60w9mkl	Cardiology	Heart and cardiovascular services	\N	Main Building, 2nd Floor	CAR-023	t	2026-09-13 15:26:13.324	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4nj005un4lgkm86vfdr	Neurology	Brain and nervous system services	\N	Main Building, 2nd Floor	NEU-024	t	2026-09-13 15:26:13.327	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4nm005vn4lgz4g0yq16	Oncology	Cancer care services	\N	Oncology Wing	ONC-025	t	2026-09-13 15:26:13.33	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4no005wn4lgrevi04ym	Renal	Kidney care and dialysis	\N	Renal Wing	REN-026	t	2026-09-13 15:26:13.333	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4nr005xn4lgldaz9me2	Respiratory	Lung and respiratory services	\N	Main Building, 1st Floor	RES-027	t	2026-09-13 15:26:13.335	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4nt005yn4lgs4qos9q8	Gastroenterology	Digestive system services	\N	Main Building, 1st Floor	GAS-028	t	2026-09-13 15:26:13.337	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4nv005zn4lgifga7mqt	Rheumatology	Autoimmune and joint disorders	\N	Main Building, 2nd Floor	RHE-029	t	2026-09-13 15:26:13.339	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4ny0060n4lgll2ii1xg	Haematology	Blood disorders services	\N	Main Building, 1st Floor	HAE-030	t	2026-09-13 15:26:13.342	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4o10061n4lgdqceqskx	Medical Education	Training and medical education	\N	3rd Floor, East Wing	MED-031	t	2026-09-13 15:26:13.345	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4o30062n4lg1o6d9aba	Research & Development	Medical research	\N	Research Wing	RND-032	t	2026-09-13 15:26:13.347	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4o50063n4lg4gg357mh	Quality Assurance	Quality and safety management	\N	Admin Wing	QA-033	t	2026-09-13 15:26:13.349	2026-09-13 15:26:11.296	default-hospital-id
\.


--
-- Data for Name: Hospital; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Hospital" (id, name, slug, code, email, phone, address, city, state, country, "logoUrl", "primaryColor", "secondaryColor", plan, status, "trialEndsAt", "subscriptionEndsAt", "maxStaff", "maxPatients", "isActive", "createdAt", "updatedAt") FROM stdin;
default-hospital-id	Default General Hospital	default-hospital	DEFAULT-HOSP	info@hospital.com	08000000000	Hospital Address	Lagos	Lagos	Nigeria	\N	#0f3460	#1a4a7a	trial	active	\N	\N	50	1000	t	2026-09-13 15:21:46.141	2026-09-13 15:26:11.296
\.


--
-- Data for Name: HospitalSettings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."HospitalSettings" (id, "tenantId", "hospitalId", "registrationFee", "cardFee", "consultationFee", "nhisMultiplier", "retainerMultiplier", "autoArchiveHours", "appointmentDuration", "enablePatientPortal", "enableKioskMode", "smsEnabled", "emailEnabled", "smsSenderId", "emailSenderName", currency, "currencySymbol", timezone, "dateFormat", "createdAt", "updatedAt") FROM stdin;
default-settings-id	default-hospital-id	default-hospital-id	2000	1000	5000	0.1	2	24	30	t	t	f	f	\N	\N	NGN	₦	Africa/Lagos	DD/MM/YYYY	2026-09-13 15:21:46.145	2026-09-13 15:26:11.296
\.


--
-- Data for Name: ImagingOrder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ImagingOrder" (id, "orderNumber", "patientId", "imagingType", "bodyPart", priority, "clinicalHistory", "clinicalQuestion", "orderingStaffId", status, result, "resultDate", report, "imagesUrl", images, "imageCount", "hasImages", "radiologistId", "billingRecordId", notes, "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: ImagingResult; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ImagingResult" (id, "imagingOrderId", findings, impression, recommendations, severity, "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: KioskSession; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."KioskSession" (id, "patientId", "sessionToken", "startedAt", "endedAt", status, "deviceInfo", "ipAddress", "tenantId") FROM stdin;
\.


--
-- Data for Name: LabOrder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LabOrder" (id, "patientId", "orderingStaffId", "labStaffId", "testName", "testType", priority, status, result, "resultDate", notes, "createdAt", "updatedAt", validated, "validatedAt", "validatedBy", "tenantId") FROM stdin;
\.


--
-- Data for Name: Medication; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Medication" (id, name, "genericName", category, supplier, "unitPrice", "stockQuantity", "reorderLevel", "expiryDate", "batchNumber", "createdAt", "updatedAt", "tenantId") FROM stdin;
cmtzyv4c2003fn4lgv434kv06	Amoxicillin 500mg Capsule	Amoxicillin	Antibiotic	Emzor	500	1000	50	2026-12-31 00:00:00	BATCH-1789313172910-WAE7	2026-09-13 15:26:12.914	2026-09-13 15:26:12.914	default-hospital-id
cmtzyv4cd003gn4lg56im3i7b	Amoxicillin-Clavulanate 625mg Tablet	Co-amoxiclav	Antibiotic	GSK	800	500	30	2026-12-31 00:00:00	BATCH-1789313172925-L07J	2026-09-13 15:26:12.925	2026-09-13 15:26:12.925	default-hospital-id
cmtzyv4ck003hn4lg4hcfybfk	Ciprofloxacin 500mg Tablet	Ciprofloxacin	Antibiotic	Bayer	600	500	30	2026-12-31 00:00:00	BATCH-1789313172932-KK32	2026-09-13 15:26:12.933	2026-09-13 15:26:12.933	default-hospital-id
cmtzyv4cq003in4lg59q6lf8x	Metronidazole 400mg Tablet	Metronidazole	Antibiotic	Sanofi	300	800	40	2026-12-31 00:00:00	BATCH-1789313172938-HQGD	2026-09-13 15:26:12.938	2026-09-13 15:26:12.938	default-hospital-id
cmtzyv4cy003jn4lg6baz7y55	Doxycycline 100mg Capsule	Doxycycline	Antibiotic	Pfizer	400	400	25	2026-12-31 00:00:00	BATCH-1789313172943-QLVQ	2026-09-13 15:26:12.947	2026-09-13 15:26:12.947	default-hospital-id
cmtzyv4d4003kn4lgoou15o3x	Azithromycin 500mg Tablet	Azithromycin	Antibiotic	Pfizer	700	300	20	2026-12-31 00:00:00	BATCH-1789313172951-E9GJ	2026-09-13 15:26:12.952	2026-09-13 15:26:12.952	default-hospital-id
cmtzyv4d9003ln4lg0ogu76aa	Ceftriaxone 1g Injection	Ceftriaxone	Antibiotic	Roche	1500	200	15	2026-12-31 00:00:00	BATCH-1789313172956-EK6U	2026-09-13 15:26:12.957	2026-09-13 15:26:12.957	default-hospital-id
cmtzyv4de003mn4lgod88qdwd	Gentamicin 80mg Injection	Gentamicin	Antibiotic	AstraZeneca	800	200	15	2026-12-31 00:00:00	BATCH-1789313172962-HG0X	2026-09-13 15:26:12.962	2026-09-13 15:26:12.962	default-hospital-id
cmtzyv4dk003nn4lg4vz40sfh	Cloxacillin 500mg Capsule	Cloxacillin	Antibiotic	Emzor	450	400	25	2026-12-31 00:00:00	BATCH-1789313172967-IVQF	2026-09-13 15:26:12.968	2026-09-13 15:26:12.968	default-hospital-id
cmtzyv4dq003on4lg1nk5161o	Erythromycin 250mg Tablet	Erythromycin	Antibiotic	Abbott	350	300	20	2026-12-31 00:00:00	BATCH-1789313172973-218M	2026-09-13 15:26:12.974	2026-09-13 15:26:12.974	default-hospital-id
cmtzyv4dv003pn4lghxh9354h	Cefuroxime 500mg Tablet	Cefuroxime	Antibiotic	GSK	650	300	20	2026-12-31 00:00:00	BATCH-1789313172978-QS5R	2026-09-13 15:26:12.979	2026-09-13 15:26:12.979	default-hospital-id
cmtzyv4e0003qn4lg6wag5hv5	Levofloxacin 500mg Tablet	Levofloxacin	Antibiotic	Bayer	550	300	20	2026-12-31 00:00:00	BATCH-1789313172983-YAJE	2026-09-13 15:26:12.984	2026-09-13 15:26:12.984	default-hospital-id
cmtzyv4e5003rn4lgmpxojg3i	Clarithromycin 500mg Tablet	Clarithromycin	Antibiotic	Abbott	750	300	20	2026-12-31 00:00:00	BATCH-1789313172988-K4MO	2026-09-13 15:26:12.989	2026-09-13 15:26:12.989	default-hospital-id
cmtzyv4ea003sn4lg8juihllw	Amikacin 500mg Injection	Amikacin	Antibiotic	AstraZeneca	1200	150	10	2026-12-31 00:00:00	BATCH-1789313172994-9ZGP	2026-09-13 15:26:12.994	2026-09-13 15:26:12.994	default-hospital-id
cmtzyv4eg003tn4lg5xphksu2	Meropenem 1g Injection	Meropenem	Antibiotic	Pfizer	2500	100	5	2026-12-31 00:00:00	BATCH-1789313172999-S8YB	2026-09-13 15:26:13	2026-09-13 15:26:13	default-hospital-id
cmtzyv4el003un4lg5pmpt7md	Amlodipine 5mg Tablet	Amlodipine	Antihypertensive	Pfizer	300	500	30	2026-12-31 00:00:00	BATCH-1789313173004-5DIU	2026-09-13 15:26:13.005	2026-09-13 15:26:13.005	default-hospital-id
cmtzyv4eq003vn4lg0ue7u9zm	Lisinopril 10mg Tablet	Lisinopril	Antihypertensive	AstraZeneca	350	400	25	2026-12-31 00:00:00	BATCH-1789313173010-P0O2	2026-09-13 15:26:13.01	2026-09-13 15:26:13.01	default-hospital-id
cmtzyv4ew003wn4lgjkyma4ob	Losartan 50mg Tablet	Losartan	Antihypertensive	MSD	400	400	25	2026-12-31 00:00:00	BATCH-1789313173015-MZ42	2026-09-13 15:26:13.016	2026-09-13 15:26:13.016	default-hospital-id
cmtzyv4f2003xn4lg0q1y38zl	Atenolol 50mg Tablet	Atenolol	Antihypertensive	GSK	250	500	30	2026-12-31 00:00:00	BATCH-1789313173021-KT34	2026-09-13 15:26:13.022	2026-09-13 15:26:13.022	default-hospital-id
cmtzyv4f7003yn4lg3jddggkg	Hydrochlorothiazide 25mg Tablet	Hydrochlorothiazide	Antihypertensive	Sanofi	200	500	30	2026-12-31 00:00:00	BATCH-1789313173026-TLUT	2026-09-13 15:26:13.027	2026-09-13 15:26:13.027	default-hospital-id
cmtzyv4fc003zn4lgej1c9d25	Nifedipine 20mg Tablet	Nifedipine	Antihypertensive	Bayer	450	300	20	2026-12-31 00:00:00	BATCH-1789313173031-ZBOL	2026-09-13 15:26:13.032	2026-09-13 15:26:13.032	default-hospital-id
cmtzyv4fh0040n4lgld9hf68i	Enalapril 5mg Tablet	Enalapril	Antihypertensive	MSD	300	400	25	2026-12-31 00:00:00	BATCH-1789313173036-OOON	2026-09-13 15:26:13.037	2026-09-13 15:26:13.037	default-hospital-id
cmtzyv4fm0041n4lgb5pgqwzx	Ramipril 5mg Tablet	Ramipril	Antihypertensive	Aventis	350	400	25	2026-12-31 00:00:00	BATCH-1789313173041-DMJI	2026-09-13 15:26:13.042	2026-09-13 15:26:13.042	default-hospital-id
cmtzyv4fs0042n4lg74hzk50i	Telmisartan 40mg Tablet	Telmisartan	Antihypertensive	Boehringer	450	300	20	2026-12-31 00:00:00	BATCH-1789313173047-28SH	2026-09-13 15:26:13.048	2026-09-13 15:26:13.048	default-hospital-id
cmtzyv4fx0043n4lg8tvxt8jx	Metoprolol 50mg Tablet	Metoprolol	Antihypertensive	AstraZeneca	300	400	25	2026-12-31 00:00:00	BATCH-1789313173053-1OFP	2026-09-13 15:26:13.053	2026-09-13 15:26:13.053	default-hospital-id
cmtzyv4g20044n4lgsbqkmvjh	Metformin 500mg Tablet	Metformin	Antidiabetic	MSD	250	500	30	2026-12-31 00:00:00	BATCH-1789313173058-ZAH0	2026-09-13 15:26:13.058	2026-09-13 15:26:13.058	default-hospital-id
cmtzyv4g70045n4lgnyffb8l3	Glibenclamide 5mg Tablet	Glibenclamide	Antidiabetic	Sanofi	200	400	25	2026-12-31 00:00:00	BATCH-1789313173063-CA7A	2026-09-13 15:26:13.063	2026-09-13 15:26:13.063	default-hospital-id
cmtzyv4gc0046n4lgnwj3n91l	Insulin NPH 100IU/ml Injection	Insulin NPH	Antidiabetic	Novo Nordisk	3000	200	15	2026-12-31 00:00:00	BATCH-1789313173068-OUQA	2026-09-13 15:26:13.069	2026-09-13 15:26:13.069	default-hospital-id
cmtzyv4gh0047n4lgbau31bm2	Insulin Regular 100IU/ml Injection	Insulin Regular	Antidiabetic	Novo Nordisk	3000	200	15	2026-12-31 00:00:00	BATCH-1789313173073-EQL9	2026-09-13 15:26:13.073	2026-09-13 15:26:13.073	default-hospital-id
cmtzyv4gn0048n4lgui0omf4m	Pioglitazone 15mg Tablet	Pioglitazone	Antidiabetic	Takeda	350	300	20	2026-12-31 00:00:00	BATCH-1789313173078-EDQC	2026-09-13 15:26:13.079	2026-09-13 15:26:13.079	default-hospital-id
cmtzyv4gr0049n4lgtvuyhc25	Gliclazide 80mg Tablet	Gliclazide	Antidiabetic	Servier	300	300	20	2026-12-31 00:00:00	BATCH-1789313173083-CZUH	2026-09-13 15:26:13.084	2026-09-13 15:26:13.084	default-hospital-id
cmtzyv4gw004an4lg8v7mo26p	Sitagliptin 100mg Tablet	Sitagliptin	Antidiabetic	MSD	800	200	15	2026-12-31 00:00:00	BATCH-1789313173088-6PGX	2026-09-13 15:26:13.089	2026-09-13 15:26:13.089	default-hospital-id
cmtzyv4h1004bn4lg9sjz4hyi	Empagliflozin 25mg Tablet	Empagliflozin	Antidiabetic	Boehringer	900	200	15	2026-12-31 00:00:00	BATCH-1789313173093-HMQL	2026-09-13 15:26:13.093	2026-09-13 15:26:13.093	default-hospital-id
cmtzyv4h6004cn4lgaplujsfv	Paracetamol 500mg Tablet	Paracetamol	Pain Reliever	Emzor	100	1000	50	2026-12-31 00:00:00	BATCH-1789313173098-OIUI	2026-09-13 15:26:13.098	2026-09-13 15:26:13.098	default-hospital-id
cmtzyv4hb004dn4lg9jl30ggn	Ibuprofen 400mg Tablet	Ibuprofen	Pain Reliever	Pfizer	200	500	30	2026-12-31 00:00:00	BATCH-1789313173103-5JDT	2026-09-13 15:26:13.103	2026-09-13 15:26:13.103	default-hospital-id
cmtzyv4hg004en4lgwccooh9p	Diclofenac 50mg Tablet	Diclofenac	Pain Reliever	Novartis	250	400	25	2026-12-31 00:00:00	BATCH-1789313173107-ZVC1	2026-09-13 15:26:13.108	2026-09-13 15:26:13.108	default-hospital-id
cmtzyv4hk004fn4lgtwyyg109	Tramadol 50mg Capsule	Tramadol	Pain Reliever	Grünenthal	350	300	20	2026-12-31 00:00:00	BATCH-1789313173112-KYEW	2026-09-13 15:26:13.112	2026-09-13 15:26:13.112	default-hospital-id
cmtzyv4hp004gn4lg1r8syjyf	Pethidine 100mg Injection	Pethidine	Pain Reliever	AstraZeneca	1200	100	10	2026-12-31 00:00:00	BATCH-1789313173117-PNXN	2026-09-13 15:26:13.117	2026-09-13 15:26:13.117	default-hospital-id
cmtzyv4hu004hn4lgp1ynbd3o	Morphine 10mg Injection	Morphine	Pain Reliever	AstraZeneca	1500	100	10	2026-12-31 00:00:00	BATCH-1789313173121-K3B7	2026-09-13 15:26:13.122	2026-09-13 15:26:13.122	default-hospital-id
cmtzyv4i0004in4lgroltg5ko	Diazepam 5mg Tablet	Diazepam	Psychiatric	Roche	350	200	15	2026-12-31 00:00:00	BATCH-1789313173127-GOC2	2026-09-13 15:26:13.128	2026-09-13 15:26:13.128	default-hospital-id
cmtzyv4i5004jn4lg5dub0442	Alprazolam 0.5mg Tablet	Alprazolam	Psychiatric	Pfizer	300	200	15	2026-12-31 00:00:00	BATCH-1789313173132-MS0J	2026-09-13 15:26:13.133	2026-09-13 15:26:13.133	default-hospital-id
cmtzyv4ia004kn4lgvxdgvnni	Olanzapine 10mg Tablet	Olanzapine	Psychiatric	Eli Lilly	800	150	10	2026-12-31 00:00:00	BATCH-1789313173138-PTK4	2026-09-13 15:26:13.138	2026-09-13 15:26:13.138	default-hospital-id
cmtzyv4if004ln4lg0vj03tlm	Clozapine 100mg Tablet	Clozapine	Psychiatric	Novartis	900	150	10	2026-12-31 00:00:00	BATCH-1789313173142-G4N4	2026-09-13 15:26:13.143	2026-09-13 15:26:13.143	default-hospital-id
cmtzyv4ik004mn4lg2w5oaxxe	Lithium 400mg Tablet	Lithium	Psychiatric	GSK	450	200	15	2026-12-31 00:00:00	BATCH-1789313173147-9DKP	2026-09-13 15:26:13.148	2026-09-13 15:26:13.148	default-hospital-id
cmtzyv4ip004nn4lgmq667gge	Adrenaline 1mg Injection	Adrenaline	Emergency	AstraZeneca	1000	100	10	2026-12-31 00:00:00	BATCH-1789313173152-RZFL	2026-09-13 15:26:13.153	2026-09-13 15:26:13.153	default-hospital-id
cmtzyv4iu004on4lghzmdwkza	Atropine 1mg Injection	Atropine	Emergency	AstraZeneca	800	100	10	2026-12-31 00:00:00	BATCH-1789313173157-OLFH	2026-09-13 15:26:13.158	2026-09-13 15:26:13.158	default-hospital-id
cmtzyv4iz004pn4lgc5lhcluf	Naloxone 0.4mg Injection	Naloxone	Emergency	Pfizer	1200	100	10	2026-12-31 00:00:00	BATCH-1789313173162-3Y73	2026-09-13 15:26:13.163	2026-09-13 15:26:13.163	default-hospital-id
cmtzyv4j4004qn4lgfgboe0jo	Dextrose 50% Injection	Dextrose	Emergency	Baxter	1500	100	10	2026-12-31 00:00:00	BATCH-1789313173167-924W	2026-09-13 15:26:13.168	2026-09-13 15:26:13.168	default-hospital-id
cmtzyv4j9004rn4lgmow76h43	Calcium Gluconate 10% Injection	Calcium Gluconate	Emergency	AstraZeneca	900	100	10	2026-12-31 00:00:00	BATCH-1789313173172-NQSP	2026-09-13 15:26:13.173	2026-09-13 15:26:13.173	default-hospital-id
cmtzyv4je004sn4lge6fqmz99	Sodium Bicarbonate 8.4% Injection	Sodium Bicarbonate	Emergency	Baxter	1000	100	10	2026-12-31 00:00:00	BATCH-1789313173177-BVS1	2026-09-13 15:26:13.178	2026-09-13 15:26:13.178	default-hospital-id
cmtzyv4jj004tn4lgm7vbb2l3	Hydrocortisone 100mg Injection	Hydrocortisone	Emergency	Pfizer	1300	100	10	2026-12-31 00:00:00	BATCH-1789313173182-P4YA	2026-09-13 15:26:13.183	2026-09-13 15:26:13.183	default-hospital-id
cmtzyv4jo004un4lgopbm0284	Chlorpheniramine 10mg Injection	Chlorpheniramine	Emergency	Sanofi	500	150	10	2026-12-31 00:00:00	BATCH-1789313173187-LNGS	2026-09-13 15:26:13.188	2026-09-13 15:26:13.188	default-hospital-id
cmtzyv4ju004vn4lgh05udmny	Chloramphenicol Eye Drops	Chloramphenicol	Ophthalmic	Bausch	1500	200	15	2026-12-31 00:00:00	BATCH-1789313173193-1F8W	2026-09-13 15:26:13.194	2026-09-13 15:26:13.194	default-hospital-id
cmtzyv4jz004wn4lgdl69uua4	Timolol Eye Drops 0.5%	Timolol	Ophthalmic	MSD	2000	150	10	2026-12-31 00:00:00	BATCH-1789313173198-Q3LN	2026-09-13 15:26:13.199	2026-09-13 15:26:13.199	default-hospital-id
cmtzyv4k4004xn4lgl6qod3zm	Artificial Tears	Hypromellose	Ophthalmic	Bausch	1000	200	15	2026-12-31 00:00:00	BATCH-1789313173203-FJIK	2026-09-13 15:26:13.204	2026-09-13 15:26:13.204	default-hospital-id
cmtzyv4k9004yn4lgk8run9g8	Latanoprost Eye Drops	Latanoprost	Ophthalmic	Pfizer	3000	100	10	2026-12-31 00:00:00	BATCH-1789313173209-DBYY	2026-09-13 15:26:13.209	2026-09-13 15:26:13.209	default-hospital-id
cmtzyv4ke004zn4lgodw11rxa	Dorzolamide Eye Drops	Dorzolamide	Ophthalmic	MSD	2500	100	10	2026-12-31 00:00:00	BATCH-1789313173213-MVBO	2026-09-13 15:26:13.214	2026-09-13 15:26:13.214	default-hospital-id
cmtzyv4kj0050n4lgxjijyahm	Hydrocortisone Cream 1%	Hydrocortisone	Topical	Pfizer	800	200	15	2026-12-31 00:00:00	BATCH-1789313173218-5JOQ	2026-09-13 15:26:13.219	2026-09-13 15:26:13.219	default-hospital-id
cmtzyv4ko0051n4lgn037bayp	Betamethasone Cream 0.1%	Betamethasone	Topical	GSK	900	200	15	2026-12-31 00:00:00	BATCH-1789313173223-0U8Y	2026-09-13 15:26:13.224	2026-09-13 15:26:13.224	default-hospital-id
cmtzyv4ks0052n4lgg2b5851x	Neomycin Cream	Neomycin	Topical	Bayer	600	200	15	2026-12-31 00:00:00	BATCH-1789313173228-WJZ5	2026-09-13 15:26:13.228	2026-09-13 15:26:13.228	default-hospital-id
cmtzyv4kx0053n4lg31b4ixyk	Silver Sulphadiazine Cream	Silver Sulphadiazine	Topical	AstraZeneca	1200	150	10	2026-12-31 00:00:00	BATCH-1789313173232-CS9L	2026-09-13 15:26:13.233	2026-09-13 15:26:13.233	default-hospital-id
cmtzyv4l10054n4lg2wuqljvf	Ketoconazole Cream	Ketoconazole	Topical	Janssen	1000	150	10	2026-12-31 00:00:00	BATCH-1789313173237-YBKS	2026-09-13 15:26:13.237	2026-09-13 15:26:13.237	default-hospital-id
cmtzyv4l50055n4lgl3xtinip	Acyclovir Cream	Acyclovir	Topical	GSK	1500	150	10	2026-12-31 00:00:00	BATCH-1789313173240-O65O	2026-09-13 15:26:13.241	2026-09-13 15:26:13.241	default-hospital-id
cmtzyv4l80056n4lgklpzbai9	Retinoic Acid Cream	Tretinoin	Topical	Janssen	2000	100	10	2026-12-31 00:00:00	BATCH-1789313173244-CCT9	2026-09-13 15:26:13.244	2026-09-13 15:26:13.244	default-hospital-id
\.


--
-- Data for Name: MedicationTransaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MedicationTransaction" (id, "medicationId", "transactionType", quantity, "unitPrice", "totalPrice", note, "staffId", "createdAt", "updatedAt", reference, "patientId", "tenantId") FROM stdin;
\.


--
-- Data for Name: NHISAuthorization; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."NHISAuthorization" (id, "authorizationNumber", "patientId", "prescriptionId", medications, "totalAmount", "nhisAmount", "patientAmount", status, "requestedBy", "approvedBy", "requestDate", "approvalDate", "expiryDate", "denialReason", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: NHISClaim; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."NHISClaim" (id, "claimNumber", "patientId", "authorizationId", "prescriptionId", "totalAmount", "nhisAmount", "patientAmount", "copayCollected", status, "submissionDate", "approvalDate", "paymentDate", "submittedBy", "approvedBy", notes, "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: NHISDrugFormulary; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."NHISDrugFormulary" (id, "medicationId", "nhisCode", "nhisName", "formularyStatus", "coverageType", "coveragePercentage", "patientCopayPercent", "maxQuantityPerPrescription", "maxRefills", "validityPeriod", "requiresPriorAuth", "requiresDiagnosis", "allowedDiagnosis", "ageRestriction", "genderRestriction", "nhisPrice", "patientPrice", "standardPrice", "effectiveDate", "expiryDate", "isActive", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: NHISDrugPrice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."NHISDrugPrice" (id, "medicationId", "nhisCode", "nhisName", "standardPrice", "nhisPrice", "patientCopay", "nhisCoverage", "maxQuantity", "refillLimit", "validityPeriod", "drugClass", "requiresPriorAuth", "isActive", "effectiveDate", "expiryDate", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: PartialPayment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PartialPayment" (id, "paymentPlanId", amount, "paymentMethod", reference, notes, "processedBy", "createdAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: Patient; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Patient" (id, "hospitalId", "firstName", "lastName", "dateOfBirth", gender, phone, email, address, "emergencyContact", allergies, "nextOfKinName", "nextOfKinPhone", "nextOfKinRelationship", "patientCategory", "insuranceProvider", "insuranceId", "corporateCompany", password, "portalAccess", "lastLogin", "isVerified", "pinCode", "mustChangePassword", "pinAttempts", "passwordAttempts", "lockedUntil", "lastPinChange", "lastPasswordChange", "isArchived", "archivedAt", "archivedReason", "archivedBy", "autoArchived", "createdAt", "updatedAt", "walletId", "accessCount", "activationRequestedAt", "archiveScheduledAt", "isActiveForModule", "lastAccessedAt", "autoArchiveAt", "dischargeNotes", "dischargeType", "dischargedAt", "dischargedBy", "fileStatus", "isDischarged", "tenantId") FROM stdin;
cmtzwkx0z00199clgfvkvkk15	000001	John	Oyelakin	1985-05-15 00:00:00	Male	08012345678	john.oye@gmail.com	123 Main Street, Lagos	08087654321	\N	Hannah Oyelakin	08087654321	Spouse	FPP	\N	\N	\N	\N	f	\N	f	\N	f	0	0	\N	\N	\N	f	\N	\N	\N	f	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	\N	0	\N	\N	t	\N	\N	\N	\N	\N	\N	ACTIVE	f	default-hospital-id
\.


--
-- Data for Name: PatientHistoryRecord; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PatientHistoryRecord" (id, "patientId", "encounterDate", "doctorName", "encounterType", diagnosis, "icd10Code", notes, "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: PatientJourney; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PatientJourney" (id, "patientId", "destinationType", "clinicId", "wardId", "registeredById", status, "cardGeneratedAt", "sentToDestinationAt", "completedAt", "archivedAt", "billingRecordId", "createdAt", "updatedAt", "cardFeeBilled", "cardFeePaid", "cardFeeRecordId", "consultationFeeBilled", "consultationFeePaid", "consultationFeeRecordId", "registrationFeeBilled", "registrationFeePaid", "registrationFeeRecordId", "activatedAt", "activatedBy", "activationRequested", "isActive", "tenantId") FROM stdin;
\.


--
-- Data for Name: PatientMessage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PatientMessage" (id, "patientId", "staffId", subject, message, "isRead", "isFromPatient", "createdAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: PatientQueue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PatientQueue" (id, "patientId", "checkInTime", "checkInMethod", status, priority, "appointmentId", "destinationType", "clinicId", "wardId", "assignedTo", "calledTime", "startTime", "endTime", notes, "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: PatientTransfer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PatientTransfer" (id, "transferNumber", "patientId", "fromLocationType", "fromClinicId", "fromWardId", "toLocationType", "toClinicId", "toWardId", reason, priority, "transportType", "requestedBy", "approvedBy", status, "requestedAt", "approvedAt", "departedAt", "arrivedAt", notes, "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: PatientWallet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PatientWallet" (id, "patientId", balance, currency, status, "lastTransactionAt", "createdAt", "updatedAt", "tenantId") FROM stdin;
cmtzwkx2j001a9clg8utmz3xp	cmtzwkx0z00199clgfvkvkk15	15000	NGN	Active	\N	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	default-hospital-id
\.


--
-- Data for Name: PaymentPlan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PaymentPlan" (id, "patientId", "billingRecordId", "totalAmount", "paidAmount", balance, status, installments, "installmentAmount", frequency, "startDate", "endDate", "nextPaymentDate", notes, "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: PharmacyBranch; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PharmacyBranch" (id, name, code, location, phone, email, "isActive", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: PharmacyStaff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PharmacyStaff" (id, "pharmacyId", "staffId", role, "isActive", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: PharmacyTransaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PharmacyTransaction" (id, "transactionNumber", "pharmacyId", "medicationId", "transactionType", quantity, "unitPrice", "totalPrice", reference, note, "staffId", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: Pregnancy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Pregnancy" (id, "patientId", "expectedDelivery", gravida, para, "lastMenstrualPeriod", "estimatedDueDate", "riskLevel", status, notes, "createdAt", "updatedAt", contractions, "deliveryDate", dilation, effacement, "laborNotes", "laborStartTime", "tenantId") FROM stdin;
\.


--
-- Data for Name: Prescription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Prescription" (id, "patientId", "prescribingStaffId", "dispensingStaffId", medication, dosage, frequency, duration, instructions, "pharmacistNotes", "dispensedAt", "rejectionReason", status, "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: ROIRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ROIRequest" (id, "requestorName", "patientName", "requestDate", "requestType", status, "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: RolePermission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RolePermission" (id, role, dashboard, patients, staff, appointments, prescriptions, "labOrders", billing, pharmacy, "pharmacyDashboard", "pharmacyInventory", "nhisManagement", "nhisAuthorizations", "pharmacyStock", "pharmacyTransactions", "pharmacyBranches", clinics, wards, pricing, "billingOfficer", wallet, "patientIntake", admissions, "patientHistory", "roiRequests", "nurseDashboard", "doctorDashboard", antenatal, "archivedPatients", "archivedPatientsView", "queueManagement", "doctorQueue", "hrDashboard", "hrEmployees", "hrDepartments", "hrLeaves", "hrAttendance", "hrPerformance", "hrTrainings", "createdAt", "updatedAt", dental, immunizations, "laborAndDelivery", optometry, "patientPortal", "portalSetup", radiology, "tenantId") FROM stdin;
cmtzwkx0g00189clgcjp0mm2e	ITSupport	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	2026-09-13 14:22:13.812	2026-09-13 14:22:13.812	f	f	f	f	f	f	f	default-hospital-id
cmtzwkwo0000t9clgvsapwyuh	Admin	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	t	t	t	t	t	t	t	default-hospital-id
cmtzwkwou000u9clgmyjvk8ct	ITAdmin	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	t	t	t	t	t	t	t	default-hospital-id
cmtzwkwpo000v9clgldvb93jp	HR	t	f	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	t	t	f	f	t	t	t	t	t	t	t	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	f	f	f	f	f	f	f	default-hospital-id
cmtzwkwqm000w9clg37cllez3	Doctor	t	t	f	t	t	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	t	f	f	t	f	f	t	f	t	f	f	f	f	f	f	f	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	f	f	f	f	f	f	f	default-hospital-id
cmtzwkwra000x9clgumdgge6t	Nurse	t	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	t	f	t	f	t	t	f	f	f	f	f	f	f	f	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	f	t	t	f	f	f	f	default-hospital-id
cmtzwkws1000y9clgtuo9c7dr	Obstetrician	t	t	f	t	t	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	t	t	f	t	f	t	f	f	f	f	f	f	f	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	f	f	t	f	f	f	f	default-hospital-id
cmtzwkwsl000z9clg2xlssq8e	Midwife	t	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	t	f	t	f	t	t	f	f	f	f	f	f	f	f	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	f	f	t	f	f	f	f	default-hospital-id
cmtzwkwt800109clg93iwdo4b	Pharmacist	t	f	f	f	t	f	f	t	t	t	t	t	t	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	f	f	f	f	f	f	f	default-hospital-id
cmtzwkwv400119clg7c7fro98	BillingOfficer	t	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	t	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	f	f	f	f	f	f	f	default-hospital-id
cmtzwkww300129clg2pw8yxhf	Accountant	t	f	f	f	f	f	t	f	f	f	t	t	f	f	f	f	f	t	f	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	f	f	f	f	f	f	f	default-hospital-id
cmtzwkwwt00139clgloov7jg8	Records	t	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	t	t	t	t	f	f	t	t	t	t	f	f	f	f	f	f	f	f	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	f	f	f	f	f	f	f	default-hospital-id
cmtzwkwxx00149clg99d0cz1m	LabTechnician	t	t	f	f	f	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	f	f	f	f	f	f	f	default-hospital-id
cmtzwkwyi00159clgxhz7qpsv	LabScientist	t	t	f	f	f	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	t	f	f	f	f	f	t	f	f	f	f	f	f	f	f	f	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	f	f	f	f	f	f	f	default-hospital-id
cmtzwkwz500169clgzfph9qtv	Radiologist	t	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	t	f	f	f	f	f	f	f	f	f	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	f	f	f	f	f	f	t	default-hospital-id
cmtzwkwzk00179clghkq4dnp0	Receptionist	t	t	f	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	f	f	f	f	f	f	f	default-hospital-id
cmtzyv6cf006yn4lgkydwsnqs	Dentist	t	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	2026-09-13 15:26:15.519	2026-09-13 15:26:11.296	t	f	f	f	f	f	f	default-hospital-id
cmtzyv6cx006zn4lgthgiunxn	Optometrist	t	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	2026-09-13 15:26:15.537	2026-09-13 15:26:11.296	f	f	f	t	f	f	f	default-hospital-id
cmtzyv6d80070n4lghd6adgv5	Paediatrician	t	t	f	t	t	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	2026-09-13 15:26:15.548	2026-09-13 15:26:11.296	f	t	f	f	f	f	f	default-hospital-id
cmtzyv6di0071n4lgbgnbdaps	Surgeon	t	t	f	t	t	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	2026-09-13 15:26:15.558	2026-09-13 15:26:11.296	f	f	f	f	f	f	f	default-hospital-id
cmtzyv6ds0072n4lgk8lwvbg2	Psychiatrist	t	t	f	t	t	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	2026-09-13 15:26:15.568	2026-09-13 15:26:11.296	f	f	f	f	f	f	f	default-hospital-id
\.


--
-- Data for Name: ServiceConfiguration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ServiceConfiguration" (id, "serviceType", name, description, "baseAmount", "isActive", "createdAt", "updatedAt", "corporateAmount", "nhisAmount", "tenantId") FROM stdin;
cmtzwkuk100019clgqwiddao1	REGISTRATION	Registration Fee	One-time registration fee	2000	t	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	\N	\N	default-hospital-id
cmtzwkuok00029clglai4axmy	CARD	ID Card Fee	Patient ID card printing fee	1000	t	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	\N	\N	default-hospital-id
cmtzwkuoo00039clgq8qtls8r	CONSULTATION	Consultation Fee	Standard consultation fee	5000	t	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	\N	\N	default-hospital-id
\.


--
-- Data for Name: ServicePrice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ServicePrice" (id, name, description, amount, "clinicId", "isActive", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: ServicePricing; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ServicePricing" (id, name, description, category, "basePrice", "nhisPrice", "corporatePrice", "isActive", "createdAt", "updatedAt", "tenantId") FROM stdin;
cmtzyv41y0018n4lgcn1qg0dw	General Consultation	Standard general consultation	FPP	5000	500	10000	t	2026-09-13 15:26:12.55	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv42d0019n4lg2d2hawib	Specialist Consultation	Consultation with specialist doctor	FPP	10000	1000	20000	t	2026-09-13 15:26:12.565	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv42g001an4lg0y1whh4q	Emergency Consultation	Emergency/urgent consultation	FPP	7500	750	15000	t	2026-09-13 15:26:12.568	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv42k001bn4lg83defn1z	Follow-up Consultation	Follow-up consultation visit	FPP	3000	300	6000	t	2026-09-13 15:26:12.572	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv42o001cn4lgcy1sgj86	Home Visit Consultation	Doctor home visit service	FPP	15000	1500	30000	t	2026-09-13 15:26:12.576	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv42r001dn4lgesgjuio8	Full Blood Count (FBC)	Complete blood count test	Lab	3500	350	7000	t	2026-09-13 15:26:12.579	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv42v001en4lg3eat8e4i	Malaria Test	Malaria parasite detection	Lab	2000	200	4000	t	2026-09-13 15:26:12.583	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv42y001fn4lg6d8lzyin	Typhoid Test (Widal)	Typhoid fever test	Lab	2500	250	5000	t	2026-09-13 15:26:12.586	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv431001gn4lgdhke3kjh	Urinalysis	Urine analysis test	Lab	1500	150	3000	t	2026-09-13 15:26:12.589	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv435001hn4lgavddi76l	Stool Analysis	Stool examination test	Lab	2000	200	4000	t	2026-09-13 15:26:12.593	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv438001in4lg4al5isfl	Blood Culture	Blood culture and sensitivity	Lab	5000	500	10000	t	2026-09-13 15:26:12.597	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv43c001jn4lg0t8v7o81	Urine Culture	Urine culture and sensitivity	Lab	4000	400	8000	t	2026-09-13 15:26:12.6	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv43g001kn4lgw54jjfsn	Sputum Culture	Sputum culture and sensitivity	Lab	4500	450	9000	t	2026-09-13 15:26:12.604	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv43o001ln4lgkbspku4o	Wound Swab Culture	Wound swab culture and sensitivity	Lab	4000	400	8000	t	2026-09-13 15:26:12.612	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv43s001mn4lgkqyust17	HIV Test	HIV antibody test	Lab	3000	300	6000	t	2026-09-13 15:26:12.616	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv43w001nn4lgp2gfc5vb	Hepatitis B Test	Hepatitis B surface antigen test	Lab	3500	350	7000	t	2026-09-13 15:26:12.62	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv43z001on4lghl6mb47p	Hepatitis C Test	Hepatitis C antibody test	Lab	3500	350	7000	t	2026-09-13 15:26:12.623	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv445001pn4lgy8n9slzs	Syphilis Test	Syphilis screening test	Lab	2500	250	5000	t	2026-09-13 15:26:12.629	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv448001qn4lgl15s1bkh	Blood Glucose Test	Blood glucose level test	Lab	1000	100	2000	t	2026-09-13 15:26:12.632	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv44c001rn4lgh81zwtyn	Lipid Profile	Cholesterol and lipid test	Lab	4000	400	8000	t	2026-09-13 15:26:12.636	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv44f001sn4lghqv16uq4	Liver Function Test	Liver enzyme and function test	Lab	5000	500	10000	t	2026-09-13 15:26:12.639	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv44i001tn4lgjoo7sxta	Kidney Function Test	Kidney function and electrolyte test	Lab	5000	500	10000	t	2026-09-13 15:26:12.642	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv44m001un4lg0wi0zmui	Thyroid Function Test	Thyroid hormone test	Lab	6000	600	12000	t	2026-09-13 15:26:12.646	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv44p001vn4lg1liimkkq	Pregnancy Test	Beta HCG pregnancy test	Lab	1500	150	3000	t	2026-09-13 15:26:12.649	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv44t001wn4lg40vwpuse	Pap Smear	Cervical cancer screening	Lab	4000	400	8000	t	2026-09-13 15:26:12.653	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv44w001xn4lgv82d45nq	Prostate Specific Antigen (PSA)	Prostate cancer screening test	Lab	5000	500	10000	t	2026-09-13 15:26:12.656	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv451001yn4lgxhbh9hm6	COVID-19 Test	COVID-19 RT-PCR test	Lab	10000	1000	20000	t	2026-09-13 15:26:12.661	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv45e001zn4lgr42ll9gx	Dengue Test	Dengue fever test	Lab	5000	500	10000	t	2026-09-13 15:26:12.674	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv45j0020n4lgtgxlqktt	Cholera Test	Cholera stool test	Lab	4000	400	8000	t	2026-09-13 15:26:12.679	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv45n0021n4lgp3jdzv97	Tuberculosis Test	TB screening test	Lab	6000	600	12000	t	2026-09-13 15:26:12.683	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv45q0022n4lg6ieiuwde	Chest X-Ray	Chest X-ray imaging	Imaging	8000	800	16000	t	2026-09-13 15:26:12.686	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv45t0023n4lg9gwaqtd8	Abdominal X-Ray	Abdominal X-ray imaging	Imaging	8000	800	16000	t	2026-09-13 15:26:12.689	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv45x0024n4lg2wi0jhi3	Pelvic X-Ray	Pelvic X-ray imaging	Imaging	8000	800	16000	t	2026-09-13 15:26:12.693	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4600025n4lgasm1jujk	Skull X-Ray	Skull X-ray imaging	Imaging	8000	800	16000	t	2026-09-13 15:26:12.696	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4630026n4lgk4au7xif	Abdominal Ultrasound	Abdominal ultrasound scan	Imaging	10000	1000	20000	t	2026-09-13 15:26:12.699	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4660027n4lgbbezi33f	Pelvic Ultrasound	Pelvic ultrasound scan	Imaging	10000	1000	20000	t	2026-09-13 15:26:12.702	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4690028n4lgke5b5kcf	Obstetric Ultrasound	Pregnancy ultrasound scan	Imaging	12000	1200	24000	t	2026-09-13 15:26:12.706	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv46d0029n4lg8oujut18	Echocardiogram	Heart ultrasound	Imaging	25000	2500	50000	t	2026-09-13 15:26:12.709	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv46g002an4lgezbn18km	CT Scan - Head	Head CT scan	Imaging	55000	5500	110000	t	2026-09-13 15:26:12.712	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv46j002bn4lgywosovuw	CT Scan - Chest	Chest CT scan	Imaging	55000	5500	110000	t	2026-09-13 15:26:12.715	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv46m002cn4lgmildbpbb	CT Scan - Abdomen	Abdominal CT scan	Imaging	60000	6000	120000	t	2026-09-13 15:26:12.719	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv46q002dn4lgfq3c2hp7	MRI - Brain	Brain MRI	Imaging	85000	8500	170000	t	2026-09-13 15:26:12.722	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv46u002en4lgq8ikjdjf	MRI - Spine	Spine MRI	Imaging	90000	9000	180000	t	2026-09-13 15:26:12.726	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv46x002fn4lgcbcjwtu4	Wound Dressing (Minor)	Minor wound dressing	Procedure	2000	200	4000	t	2026-09-13 15:26:12.729	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv470002gn4lgg9n31qgg	Wound Dressing (Major)	Major wound dressing	Procedure	5000	500	10000	t	2026-09-13 15:26:12.732	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv474002hn4lgcgi5j7tk	Suturing (Minor)	Minor wound suturing	Procedure	5000	500	10000	t	2026-09-13 15:26:12.736	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv477002in4lg7wxyoglm	Suturing (Major)	Major wound suturing	Procedure	10000	1000	20000	t	2026-09-13 15:26:12.739	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv47c002jn4lgqk61mtfq	Incision & Drainage	Incision and drainage procedure	Procedure	7000	700	14000	t	2026-09-13 15:26:12.744	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv47f002kn4lgda63rgk7	Biopsy	Tissue biopsy procedure	Procedure	15000	1500	30000	t	2026-09-13 15:26:12.747	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv47i002ln4lgqlgh9t4y	IV Cannulation	IV line insertion	Procedure	15000	1500	30000	t	2026-09-13 15:26:12.75	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv47l002mn4lgjtcrc6lo	Blood Transfusion	Blood transfusion procedure	Procedure	25000	2500	50000	t	2026-09-13 15:26:12.753	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv47o002nn4lg8s5ghzl3	Lumbar Puncture	Spinal tap procedure	Procedure	20000	2000	40000	t	2026-09-13 15:26:12.756	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv47r002on4lgvh59uqty	Chest Tube Insertion	Chest tube placement	Procedure	30000	3000	60000	t	2026-09-13 15:26:12.759	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv47w002pn4lgdt2qhcx6	Peritoneal Dialysis	Peritoneal dialysis procedure	Procedure	40000	4000	80000	t	2026-09-13 15:26:12.764	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv480002qn4lgggnh9jyt	Haemodialysis	Haemodialysis treatment	Procedure	50000	5000	100000	t	2026-09-13 15:26:12.768	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv483002rn4lgf5rzxl8j	Endoscopy	Upper GI endoscopy	Procedure	35000	3500	70000	t	2026-09-13 15:26:12.771	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv486002sn4lge10ijy7g	Colonoscopy	Colonoscopy procedure	Procedure	40000	4000	80000	t	2026-09-13 15:26:12.774	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv489002tn4lga2lopfor	Bronchoscopy	Bronchoscopy procedure	Procedure	35000	3500	70000	t	2026-09-13 15:26:12.777	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv48c002un4lgq7wobpjg	Cystoscopy	Cystoscopy procedure	Procedure	30000	3000	60000	t	2026-09-13 15:26:12.78	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv48f002vn4lgimge6oyw	Hysteroscopy	Hysteroscopy procedure	Procedure	35000	3500	70000	t	2026-09-13 15:26:12.783	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv48i002wn4lglu9carcg	Laparoscopy	Laparoscopy procedure	Procedure	45000	4500	90000	t	2026-09-13 15:26:12.786	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv48q002xn4lgjnprxypo	Arthroscopy	Arthroscopy procedure	Procedure	40000	4000	80000	t	2026-09-13 15:26:12.794	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv48t002yn4lgmxidii0f	Cardiac Catheterization	Cardiac catheterization procedure	Procedure	80000	8000	160000	t	2026-09-13 15:26:12.797	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv48x002zn4lg6uipncq5	Dental Consultation	Dental examination and consultation	Dental	3000	300	6000	t	2026-09-13 15:26:12.801	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4900030n4lga69ddz3y	Tooth Extraction	Simple tooth extraction	Dental	5000	500	10000	t	2026-09-13 15:26:12.804	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4930031n4lgzj8tm9l5	Dental Filling	Dental filling procedure	Dental	7000	700	14000	t	2026-09-13 15:26:12.807	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4960032n4lggzbdau8u	Dental Cleaning	Professional dental cleaning	Dental	8000	800	16000	t	2026-09-13 15:26:12.81	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv49a0033n4lgdjhfnx07	Root Canal	Root canal treatment	Dental	25000	2500	50000	t	2026-09-13 15:26:12.814	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv49e0034n4lgor760mys	Crown & Bridge	Dental crown and bridge	Dental	40000	4000	80000	t	2026-09-13 15:26:12.818	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv49i0035n4lgfjbix73h	Dentures	Denture fitting	Dental	50000	5000	100000	t	2026-09-13 15:26:12.822	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv49m0036n4lg5677buip	Teeth Whitening	Professional teeth whitening	Dental	20000	2000	40000	t	2026-09-13 15:26:12.826	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv49p0037n4lgy2dozjzx	Orthodontics	Orthodontic treatment	Dental	60000	6000	120000	t	2026-09-13 15:26:12.829	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv49t0038n4lgc3gp2qbs	Dental Implant	Dental implant procedure	Dental	100000	10000	200000	t	2026-09-13 15:26:12.833	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv49w0039n4lgmvcntoig	Eye Examination	Comprehensive eye exam	Optometry	5000	500	10000	t	2026-09-13 15:26:12.837	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4a0003an4lg4laak8fv	Visual Field Test	Visual field assessment	Optometry	8000	800	16000	t	2026-09-13 15:26:12.84	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4a3003bn4lgcp640qwc	Glaucoma Screening	Glaucoma screening test	Optometry	10000	1000	20000	t	2026-09-13 15:26:12.843	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4a8003cn4lg6zo88q4l	Retinal Imaging	Retinal photography	Optometry	15000	1500	30000	t	2026-09-13 15:26:12.848	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4ab003dn4lgdrshyobb	Contact Lens Fitting	Contact lens fitting	Optometry	12000	1200	24000	t	2026-09-13 15:26:12.851	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4af003en4lgvfszfd4v	Spectacle Prescription	Glasses prescription	Optometry	3000	300	6000	t	2026-09-13 15:26:12.855	2026-09-13 15:26:11.296	default-hospital-id
\.


--
-- Data for Name: Staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Staff" (id, "employeeId", username, "firstName", "lastName", email, role, password, "isActive", manager_id, "dateOfBirth", gender, phone, address, "emergencyContact", "employmentType", "startDate", "endDate", salary, "bankName", "bankAccount", "bankBranch", "taxId", "nationalId", "createdAt", "updatedAt", "departmentId", "tenantId") FROM stdin;
cmtzy1zet000088lgjpdh9g3t	ADMIN002	adeboye-daniel	Daniel	Adeboye	dan@gmail.com	Admin	$2b$10$5I/vi7GoSMTePiN64d0VxeQJYcgNVxG4fE3os6ciibSG8UIE0/Y6y	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-13 15:03:33.51	2026-09-13 15:03:33.491	\N	default-hospital-id
cmtzwkwan000e9clg98g591dx	ADMIN001	admin	System	Administrator	admin@hospital.com	Admin	$2b$10$2FPcqcbZMJ06GvHM7Sjxo.9ONok6p5JC1gCASX.kfXfeogVZ09Md.	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	\N	default-hospital-id
cmtzwkwee000f9clgez0t4otk	IT001	itadmin	IT	Admin	itadmin@hospital.com	ITAdmin	$2b$10$RAMd91E75ELC9XWuZ8OGX.oVd2mtVhZai1KEGejMEe9CHcKNkFt.q	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	\N	default-hospital-id
cmtzwkwf6000g9clg6us0n9r7	HR001	hr	HR	Manager	hr@hospital.com	HR	$2b$10$yIaJdgjfJfwzd6Vhc4n06uP4YDbEbX8KYuWBb69ekK7NxG7HfXb4y	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	\N	default-hospital-id
cmtzwkwft000h9clg9ecjev5a	DOC001	doctor	John	Doctor	doctor@hospital.com	Doctor	$2b$10$lzhD0x1feLXp331gyxksye6AzszggOjOQgM/O8MM3gAKjOnzozV8.	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	\N	default-hospital-id
cmtzwkwgd000i9clg4izts408	NURSE001	nurse	Sarah	Nurse	nurse@hospital.com	Nurse	$2b$10$0Ioz31.Zt29WSPTRTsbEcOUZkTnU8g6pw5Mz4MjrbSD3G2N/FPSXu	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	\N	default-hospital-id
cmtzwkwgx000j9clgpu7s6q0m	BILL001	billing	Billing	Officer	billing@hospital.com	BillingOfficer	$2b$10$Gi020fIIgF7hMqstznrMZ.72gZRO6g5sIskGRlBI5LF4NlwsJoM1q	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	\N	default-hospital-id
cmtzwkwht000k9clgjx6pl99u	PHARM001	pharmacist	Pharmacy	Staff	pharmacist@hospital.com	Pharmacist	$2b$10$mgO3/OkokAiW1lxBZ3ZszuQVgqlFj34vmDzDCjNBtmmq7qDaACgK2	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	\N	default-hospital-id
cmtzwkwib000l9clganubskzd	LAB001	labtech	Lab	Technician	labtech@hospital.com	LabTechnician	$2b$10$jY1UySzdO2DqmDu.X.IyduwKCimsuy/lHp0IAUKIs6iQzRNAMA0XO	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	\N	default-hospital-id
cmtzwkwix000m9clgn0jpbm92	LABSCI001	labscientist	Lab	Scientist	labscientist@hospital.com	LabScientist	$2b$10$JDJNV2wkB5BuYa4zadx/HO/wqgCIEC6vtO6sHUaJU06rE7Yr9jM5i	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	\N	default-hospital-id
cmtzwkwjt000n9clgfagjf9pa	RAD001	radiologist	Radiology	Specialist	radiologist@hospital.com	Radiologist	$2b$10$mXxUhwEFgSx/oa5Ces75g.ZPHKb7BlZbAhtR3xpoikRroi2W74XPO	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	\N	default-hospital-id
cmtzwkwkj000o9clg7nhw51zl	ACC001	accountant	Account	Ant	accountant@hospital.com	Accountant	$2b$10$FikgJxI4FR9eT7ahDJ9hlug2xORFPK/2OQI23OcRqihAsuavYhtEm	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	\N	default-hospital-id
cmtzwkwl5000p9clgcesd6mye	REC001	records	Records	Officer	records@hospital.com	Records	$2b$10$V2SHjHyr1lcNgfaVEo7Dd.yagIOyVdQgRRWIB/pPduId0l3DhSk/O	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	\N	default-hospital-id
cmtzwkwlw000q9clgcz4etfix	OBG001	obstetrician	Obstetrics	Specialist	obstetrician@hospital.com	Obstetrician	$2b$10$WcreFMQdjb9Sqoo/wBnUh.k9OqPIji38DVwR422q/JCC4DEW2rV3W	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	\N	default-hospital-id
cmtzwkwmf000r9clgksjagp2w	MID001	midwife	Midwife	Staff	midwife@hospital.com	Midwife	$2b$10$ccTyIuMTJqXfQXWJBepr9Onwep7mwYBjcn7u35X7llFEeKfzpfU/C	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	\N	default-hospital-id
cmtzwkwn1000s9clg1g4fkeaf	RECEPT001	receptionist	Reception	Staff	receptionist@hospital.com	Receptionist	$2b$10$TM/I9ExOGyNl4g6Liojy5uEWbCHeSnoCidJYzhXRY//aQnu.iDOru	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	\N	default-hospital-id
\.


--
-- Data for Name: StaffClinic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."StaffClinic" ("staffId", "clinicId", "tenantId") FROM stdin;
\.


--
-- Data for Name: StaffWard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."StaffWard" ("staffId", "wardId", "tenantId") FROM stdin;
\.


--
-- Data for Name: VitalSign; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."VitalSign" (id, "patientId", "nurseId", "recordedAt", "bloodPressureSystolic", "bloodPressureDiastolic", "heartRate", temperature, "respiratoryRate", "oxygenSaturation", weight, height, notes, "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: WalletTransaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WalletTransaction" (id, "walletId", "transactionType", amount, "balanceBefore", "balanceAfter", description, reference, status, "billingRecordId", category, "serviceId", "serviceType", "paymentReference", "processedAt", "processedBy", "paidToStaffId", "paymentMethod", notes, "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: Ward; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Ward" (id, name, description, capacity, "createdAt", "updatedAt", "tenantId") FROM stdin;
cmtzwkutt000c9clgggig17ns	Surgical Ward	Post-surgical recovery	25	2026-09-13 14:22:13.812	2026-09-13 14:22:13.812	default-hospital-id
cmtzwkutw000d9clgiy05ioxw	Private Ward	Private rooms for patients	10	2026-09-13 14:22:13.812	2026-09-13 14:22:13.812	default-hospital-id
cmtzyv3zl000ln4lgowdoxic4	Medical Ward (Male)	General medical care for male patients	30	2026-09-13 15:26:12.465	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv3zu000mn4lg7v3tpmae	Medical Ward (Female)	General medical care for female patients	30	2026-09-13 15:26:12.474	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv3zx000nn4lgq9fc0je2	Surgical Ward (Male)	Surgical care for male patients	25	2026-09-13 15:26:12.477	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv401000on4lgcsne58df	Surgical Ward (Female)	Surgical care for female patients	25	2026-09-13 15:26:12.481	2026-09-13 15:26:11.296	default-hospital-id
cmtzwkuto000b9clggxnoz3hi	Paediatric Ward	Care for children and infants	20	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	default-hospital-id
cmtzwkutl000a9clg7sfi8axp	Maternity Ward	Maternity and delivery care	25	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv40d000rn4lg5wpuor0d	Labour Ward	Labour and delivery suites	10	2026-09-13 15:26:12.493	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv40h000sn4lgl0jkenn1	Antenatal Ward	Pregnancy care and monitoring	15	2026-09-13 15:26:12.497	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv40k000tn4lg5cgcuk47	Postnatal Ward	Post-delivery care for mothers	20	2026-09-13 15:26:12.5	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv40n000un4lgotpfkcb5	ICU - Intensive Care Unit	Critical care for seriously ill patients	10	2026-09-13 15:26:12.503	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv40q000vn4lgik8wegxo	HDU - High Dependency Unit	High dependency care	10	2026-09-13 15:26:12.506	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv40t000wn4lgst14somb	Neonatal ICU (NICU)	Special care for newborns	15	2026-09-13 15:26:12.509	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv40w000xn4lgulcd2afj	Orthopaedic Ward	Bone and joint care	20	2026-09-13 15:26:12.512	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv40z000yn4lgu7bn5u6v	Oncology Ward	Cancer care unit	15	2026-09-13 15:26:12.515	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv412000zn4lg08kygxlz	Psychiatric Ward	Mental health care	15	2026-09-13 15:26:12.518	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4150010n4lg1s4j6c2k	Isolation Ward	Isolation for infectious diseases	10	2026-09-13 15:26:12.521	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv4180011n4lgz33fwllk	Daycare Ward	Day care procedures and observation	10	2026-09-13 15:26:12.524	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv41b0012n4lgskspqdxu	Private Ward (Premium)	Premium private care	5	2026-09-13 15:26:12.527	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv41e0013n4lg0uql1ylv	VIP Ward	VIP care suites	3	2026-09-13 15:26:12.53	2026-09-13 15:26:11.296	default-hospital-id
cmtzwkut400099clgbhummudb	General Ward	General ward care	40	2026-09-13 14:22:13.812	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv41k0015n4lgscqi0y0h	Recovery Ward	Post-surgery recovery	15	2026-09-13 15:26:12.536	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv41n0016n4lgkt6se3xt	Burns Unit	Burn care and treatment	8	2026-09-13 15:26:12.539	2026-09-13 15:26:11.296	default-hospital-id
cmtzyv41r0017n4lg2od6m96x	Dialysis Unit	Dialysis treatment	10	2026-09-13 15:26:12.543	2026-09-13 15:26:11.296	default-hospital-id
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
8df4b5d5-e59e-43d1-84eb-eba86a34ee6c	df74ead76401db2fae0018d79b7ae736128ce7197c91464da0434c714a9da984	2026-09-13 15:21:45.876374+01	20260828140059_add_billing_wallet_improvements	\N	\N	2026-09-13 15:21:44.378991+01	1
1035b763-b550-4765-b8f1-7ab3cb12aa1b	dc51cd2ba5ad98ebbe5b0d4c87934cbbd64da0ba7c9f42590389ea32c4cedce4	2026-09-13 15:21:45.924463+01	20260829074939_add_service_config_and_journey_fees	\N	\N	2026-09-13 15:21:45.87766+01	1
06d7d0d1-a6fc-43b2-bc06-38791367bad5	76754fdeaa22a37e3cb010e34b467367280377b548a6062452d2071768c5ac09	2026-09-13 15:21:45.971381+01	20260830184409_add_enhanced_billing_and_service_config	\N	\N	2026-09-13 15:21:45.92725+01	1
cf8bec37-c3b6-49ce-9cbf-c674e8d88aae	ccf34fbeedd62ca3f77c5dda6b4b31fb5542085d091600f621fd1df5fe8010c6	2026-09-13 15:21:45.989647+01	20260831093410_add_lab_validation_fields	\N	\N	2026-09-13 15:21:45.973019+01	1
e065ac16-8557-4c35-a143-3a68f5be48da	ca798967463d274c59e1de3f389db279e56b5c3d0e3937101fd2f7ed098036c3	2026-09-13 15:21:46.004227+01	20260901105538_add_archive_control_and_missing_updated_at	\N	\N	2026-09-13 15:21:45.990844+01	1
eb7a9a5b-b777-4c51-b93a-ed9cb2c225b7	238643a92acef62a2fff8f8f014dbf18e3f8b57557d2049aa7d9089d0b5448f1	2026-09-13 15:21:46.016603+01	20260901155404_add_labor_and_delivery_permission	\N	\N	2026-09-13 15:21:46.005872+01	1
dae63783-bf5f-4d9d-809a-40d57b2264ce	c10a22bf83f5379180ffbf5c8eba93a87301977add1eb7133364ea212ed84b93	2026-09-13 15:21:46.063877+01	20260911111042_add_discharge_tracking	\N	\N	2026-09-13 15:21:46.019434+01	1
b24a0c99-cc55-422a-800a-a2e11dae7a85	b72f309aedb756478bae147cf6c9771f097615b27bb16543957754d4b840e1f4	2026-09-13 15:21:46.069815+01	20260912221732_add_reference_to_medication_transaction	\N	\N	2026-09-13 15:21:46.064895+01	1
0b21fd5a-2282-40ad-939c-dbd764863bda	bb965d85c634cc8895fa0f08327117352b2d613345aa235ead39512bc5bb87aa	2026-09-13 15:21:46.079393+01	20260912222901_add_patient_and_reference_to_medication_transaction	\N	\N	2026-09-13 15:21:46.07176+01	1
26d44d5f-560e-480d-aae9-399254b4d173	b4561ceca8910bf8dfa5fc17fa8c4bcc68db46a3b08f07451ea57966010da02d	2026-09-13 15:21:47.049429+01	20260913114350_add_multi_tenancy	\N	\N	2026-09-13 15:21:46.080975+01	1
\.


--
-- Data for Name: attendance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attendance (id, staff_id, date, clock_in, clock_out, notes, created_at, updated_at, "tenantId") FROM stdin;
\.


--
-- Data for Name: dental_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dental_records (id, "patientId", "examinationDate", "teethNumber", condition, "treatmentPlan", procedure, notes, "staffId", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: immunizations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.immunizations (id, "patientId", "vaccineName", "doseNumber", "administrationDate", route, site, "batchNumber", "expiryDate", "nextDueDate", "administeredBy", notes, "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: leave_notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.leave_notifications (id, leave_request_id, staff_id, notification_type, message, scheduled_date, sent_at, status, is_read, read_at, is_global, created_at, updated_at, "tenantId") FROM stdin;
\.


--
-- Data for Name: leave_policies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.leave_policies (id, name, description, default_annual_days, default_sick_days, default_study_days, default_maternity_days, default_paternity_days, max_carry_over_days, carry_over_expiry, leave_year_start_month, leave_year_end_month, pro_rata_enabled, reminder_days, is_active, created_at, updated_at, "tenantId") FROM stdin;
\.


--
-- Data for Name: leave_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.leave_requests (id, staff_id, leave_type, start_date, end_date, days, reason, contact_during_leave, substitute_id, status, approved_by_id, approved_at, comments, created_at, updated_at, leave_usage_id, "tenantId") FROM stdin;
\.


--
-- Data for Name: leave_usages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.leave_usages (id, staff_id, leave_request_id, entitlement_id, leave_type, days_used, start_date, end_date, status, approved_by_id, approved_at, notes, created_at, updated_at, "tenantId") FROM stdin;
\.


--
-- Data for Name: optometry_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.optometry_records (id, "patientId", "examinationDate", "visualAcuityRight", "visualAcuityLeft", "intraocularPressureRight", "intraocularPressureLeft", "refractionRight", "refractionLeft", diagnosis, treatment, prescription, notes, "staffId", "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: patient_notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patient_notifications (id, "patientId", title, message, type, "isRead", link, "createdAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: performance_reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.performance_reviews (id, staff_id, reviewer_id, review_date, period_start, period_end, rating, strengths, weaknesses, goals, recommendations, overall_comments, created_at, updated_at, "tenantId") FROM stdin;
\.


--
-- Data for Name: staff_leave_entitlements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff_leave_entitlements (id, staff_id, year, annual_leave_days, sick_leave_days, study_leave_days, maternity_leave_days, paternity_leave_days, unpaid_leave_days, carried_over_days, total_available_days, used_annual_days, used_sick_days, used_study_days, used_maternity_days, used_paternity_days, used_unpaid_days, remaining_annual_days, remaining_sick_days, remaining_study_days, remaining_maternity_days, remaining_paternity_days, remaining_unpaid_days, is_active, is_locked, created_by, updated_by, notes, created_at, updated_at, "tenantId") FROM stdin;
\.


--
-- Data for Name: staff_trainings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff_trainings (staff_id, training_id, enrollment_date, completion_date, completion_status, certificate_issued, score, created_at, updated_at, "tenantId") FROM stdin;
\.


--
-- Data for Name: trainings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trainings (id, title, description, provider, start_date, end_date, cost, location, max_participants, certificate_provided, created_at, updated_at, "tenantId") FROM stdin;
\.


--
-- Name: Admission Admission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Admission"
    ADD CONSTRAINT "Admission_pkey" PRIMARY KEY (id);


--
-- Name: AntenatalVisit AntenatalVisit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AntenatalVisit"
    ADD CONSTRAINT "AntenatalVisit_pkey" PRIMARY KEY (id);


--
-- Name: AppointmentReminder AppointmentReminder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppointmentReminder"
    ADD CONSTRAINT "AppointmentReminder_pkey" PRIMARY KEY (id);


--
-- Name: Appointment Appointment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appointment"
    ADD CONSTRAINT "Appointment_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: BillingRecord BillingRecord_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BillingRecord"
    ADD CONSTRAINT "BillingRecord_pkey" PRIMARY KEY (id);


--
-- Name: Clinic Clinic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Clinic"
    ADD CONSTRAINT "Clinic_pkey" PRIMARY KEY (id);


--
-- Name: ClinicalNote ClinicalNote_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClinicalNote"
    ADD CONSTRAINT "ClinicalNote_pkey" PRIMARY KEY (id);


--
-- Name: Delivery Delivery_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Delivery"
    ADD CONSTRAINT "Delivery_pkey" PRIMARY KEY (id);


--
-- Name: Department Department_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Department"
    ADD CONSTRAINT "Department_pkey" PRIMARY KEY (id);


--
-- Name: HospitalSettings HospitalSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."HospitalSettings"
    ADD CONSTRAINT "HospitalSettings_pkey" PRIMARY KEY (id);


--
-- Name: Hospital Hospital_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Hospital"
    ADD CONSTRAINT "Hospital_pkey" PRIMARY KEY (id);


--
-- Name: ImagingOrder ImagingOrder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ImagingOrder"
    ADD CONSTRAINT "ImagingOrder_pkey" PRIMARY KEY (id);


--
-- Name: ImagingResult ImagingResult_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ImagingResult"
    ADD CONSTRAINT "ImagingResult_pkey" PRIMARY KEY (id);


--
-- Name: KioskSession KioskSession_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KioskSession"
    ADD CONSTRAINT "KioskSession_pkey" PRIMARY KEY (id);


--
-- Name: LabOrder LabOrder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LabOrder"
    ADD CONSTRAINT "LabOrder_pkey" PRIMARY KEY (id);


--
-- Name: MedicationTransaction MedicationTransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MedicationTransaction"
    ADD CONSTRAINT "MedicationTransaction_pkey" PRIMARY KEY (id);


--
-- Name: Medication Medication_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Medication"
    ADD CONSTRAINT "Medication_pkey" PRIMARY KEY (id);


--
-- Name: NHISAuthorization NHISAuthorization_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NHISAuthorization"
    ADD CONSTRAINT "NHISAuthorization_pkey" PRIMARY KEY (id);


--
-- Name: NHISClaim NHISClaim_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NHISClaim"
    ADD CONSTRAINT "NHISClaim_pkey" PRIMARY KEY (id);


--
-- Name: NHISDrugFormulary NHISDrugFormulary_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NHISDrugFormulary"
    ADD CONSTRAINT "NHISDrugFormulary_pkey" PRIMARY KEY (id);


--
-- Name: NHISDrugPrice NHISDrugPrice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NHISDrugPrice"
    ADD CONSTRAINT "NHISDrugPrice_pkey" PRIMARY KEY (id);


--
-- Name: PartialPayment PartialPayment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PartialPayment"
    ADD CONSTRAINT "PartialPayment_pkey" PRIMARY KEY (id);


--
-- Name: PatientHistoryRecord PatientHistoryRecord_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientHistoryRecord"
    ADD CONSTRAINT "PatientHistoryRecord_pkey" PRIMARY KEY (id);


--
-- Name: PatientJourney PatientJourney_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientJourney"
    ADD CONSTRAINT "PatientJourney_pkey" PRIMARY KEY (id);


--
-- Name: PatientMessage PatientMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientMessage"
    ADD CONSTRAINT "PatientMessage_pkey" PRIMARY KEY (id);


--
-- Name: PatientQueue PatientQueue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientQueue"
    ADD CONSTRAINT "PatientQueue_pkey" PRIMARY KEY (id);


--
-- Name: PatientTransfer PatientTransfer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientTransfer"
    ADD CONSTRAINT "PatientTransfer_pkey" PRIMARY KEY (id);


--
-- Name: PatientWallet PatientWallet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientWallet"
    ADD CONSTRAINT "PatientWallet_pkey" PRIMARY KEY (id);


--
-- Name: Patient Patient_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Patient"
    ADD CONSTRAINT "Patient_pkey" PRIMARY KEY (id);


--
-- Name: PaymentPlan PaymentPlan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentPlan"
    ADD CONSTRAINT "PaymentPlan_pkey" PRIMARY KEY (id);


--
-- Name: PharmacyBranch PharmacyBranch_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PharmacyBranch"
    ADD CONSTRAINT "PharmacyBranch_pkey" PRIMARY KEY (id);


--
-- Name: PharmacyStaff PharmacyStaff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PharmacyStaff"
    ADD CONSTRAINT "PharmacyStaff_pkey" PRIMARY KEY (id);


--
-- Name: PharmacyTransaction PharmacyTransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PharmacyTransaction"
    ADD CONSTRAINT "PharmacyTransaction_pkey" PRIMARY KEY (id);


--
-- Name: Pregnancy Pregnancy_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pregnancy"
    ADD CONSTRAINT "Pregnancy_pkey" PRIMARY KEY (id);


--
-- Name: Prescription Prescription_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Prescription"
    ADD CONSTRAINT "Prescription_pkey" PRIMARY KEY (id);


--
-- Name: ROIRequest ROIRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ROIRequest"
    ADD CONSTRAINT "ROIRequest_pkey" PRIMARY KEY (id);


--
-- Name: RolePermission RolePermission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_pkey" PRIMARY KEY (id);


--
-- Name: ServiceConfiguration ServiceConfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceConfiguration"
    ADD CONSTRAINT "ServiceConfiguration_pkey" PRIMARY KEY (id);


--
-- Name: ServicePrice ServicePrice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServicePrice"
    ADD CONSTRAINT "ServicePrice_pkey" PRIMARY KEY (id);


--
-- Name: ServicePricing ServicePricing_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServicePricing"
    ADD CONSTRAINT "ServicePricing_pkey" PRIMARY KEY (id);


--
-- Name: StaffClinic StaffClinic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StaffClinic"
    ADD CONSTRAINT "StaffClinic_pkey" PRIMARY KEY ("tenantId", "staffId", "clinicId");


--
-- Name: StaffWard StaffWard_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StaffWard"
    ADD CONSTRAINT "StaffWard_pkey" PRIMARY KEY ("tenantId", "staffId", "wardId");


--
-- Name: Staff Staff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Staff"
    ADD CONSTRAINT "Staff_pkey" PRIMARY KEY (id);


--
-- Name: VitalSign VitalSign_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VitalSign"
    ADD CONSTRAINT "VitalSign_pkey" PRIMARY KEY (id);


--
-- Name: WalletTransaction WalletTransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WalletTransaction"
    ADD CONSTRAINT "WalletTransaction_pkey" PRIMARY KEY (id);


--
-- Name: Ward Ward_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ward"
    ADD CONSTRAINT "Ward_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: attendance attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_pkey PRIMARY KEY (id);


--
-- Name: dental_records dental_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dental_records
    ADD CONSTRAINT dental_records_pkey PRIMARY KEY (id);


--
-- Name: immunizations immunizations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.immunizations
    ADD CONSTRAINT immunizations_pkey PRIMARY KEY (id);


--
-- Name: leave_notifications leave_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_notifications
    ADD CONSTRAINT leave_notifications_pkey PRIMARY KEY (id);


--
-- Name: leave_policies leave_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_policies
    ADD CONSTRAINT leave_policies_pkey PRIMARY KEY (id);


--
-- Name: leave_requests leave_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_pkey PRIMARY KEY (id);


--
-- Name: leave_usages leave_usages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_usages
    ADD CONSTRAINT leave_usages_pkey PRIMARY KEY (id);


--
-- Name: optometry_records optometry_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optometry_records
    ADD CONSTRAINT optometry_records_pkey PRIMARY KEY (id);


--
-- Name: patient_notifications patient_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_notifications
    ADD CONSTRAINT patient_notifications_pkey PRIMARY KEY (id);


--
-- Name: performance_reviews performance_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.performance_reviews
    ADD CONSTRAINT performance_reviews_pkey PRIMARY KEY (id);


--
-- Name: staff_leave_entitlements staff_leave_entitlements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_leave_entitlements
    ADD CONSTRAINT staff_leave_entitlements_pkey PRIMARY KEY (id);


--
-- Name: staff_trainings staff_trainings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_trainings
    ADD CONSTRAINT staff_trainings_pkey PRIMARY KEY ("tenantId", staff_id, training_id);


--
-- Name: trainings trainings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trainings
    ADD CONSTRAINT trainings_pkey PRIMARY KEY (id);


--
-- Name: Admission_tenantId_admissionNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Admission_tenantId_admissionNumber_key" ON public."Admission" USING btree ("tenantId", "admissionNumber");


--
-- Name: Admission_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Admission_tenantId_idx" ON public."Admission" USING btree ("tenantId");


--
-- Name: AntenatalVisit_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AntenatalVisit_tenantId_idx" ON public."AntenatalVisit" USING btree ("tenantId");


--
-- Name: AppointmentReminder_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AppointmentReminder_tenantId_idx" ON public."AppointmentReminder" USING btree ("tenantId");


--
-- Name: Appointment_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Appointment_tenantId_idx" ON public."Appointment" USING btree ("tenantId");


--
-- Name: Appointment_tenantId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Appointment_tenantId_status_idx" ON public."Appointment" USING btree ("tenantId", status);


--
-- Name: AuditLog_tenantId_action_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditLog_tenantId_action_idx" ON public."AuditLog" USING btree ("tenantId", action);


--
-- Name: AuditLog_tenantId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditLog_tenantId_createdAt_idx" ON public."AuditLog" USING btree ("tenantId", "createdAt");


--
-- Name: AuditLog_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditLog_tenantId_idx" ON public."AuditLog" USING btree ("tenantId");


--
-- Name: BillingRecord_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "BillingRecord_tenantId_idx" ON public."BillingRecord" USING btree ("tenantId");


--
-- Name: BillingRecord_tenantId_invoiceNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "BillingRecord_tenantId_invoiceNumber_key" ON public."BillingRecord" USING btree ("tenantId", "invoiceNumber");


--
-- Name: BillingRecord_tenantId_paymentReference_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "BillingRecord_tenantId_paymentReference_key" ON public."BillingRecord" USING btree ("tenantId", "paymentReference");


--
-- Name: BillingRecord_tenantId_receiptNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "BillingRecord_tenantId_receiptNumber_key" ON public."BillingRecord" USING btree ("tenantId", "receiptNumber");


--
-- Name: BillingRecord_tenantId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "BillingRecord_tenantId_status_idx" ON public."BillingRecord" USING btree ("tenantId", status);


--
-- Name: Clinic_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Clinic_tenantId_idx" ON public."Clinic" USING btree ("tenantId");


--
-- Name: Clinic_tenantId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Clinic_tenantId_name_key" ON public."Clinic" USING btree ("tenantId", name);


--
-- Name: ClinicalNote_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClinicalNote_tenantId_idx" ON public."ClinicalNote" USING btree ("tenantId");


--
-- Name: Delivery_pregnancyId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Delivery_pregnancyId_key" ON public."Delivery" USING btree ("pregnancyId");


--
-- Name: Delivery_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Delivery_tenantId_idx" ON public."Delivery" USING btree ("tenantId");


--
-- Name: Department_managerId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Department_managerId_key" ON public."Department" USING btree ("managerId");


--
-- Name: Department_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Department_tenantId_idx" ON public."Department" USING btree ("tenantId");


--
-- Name: Department_tenantId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Department_tenantId_name_key" ON public."Department" USING btree ("tenantId", name);


--
-- Name: HospitalSettings_hospitalId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "HospitalSettings_hospitalId_key" ON public."HospitalSettings" USING btree ("hospitalId");


--
-- Name: HospitalSettings_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "HospitalSettings_tenantId_key" ON public."HospitalSettings" USING btree ("tenantId");


--
-- Name: Hospital_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Hospital_code_key" ON public."Hospital" USING btree (code);


--
-- Name: Hospital_slug_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Hospital_slug_key" ON public."Hospital" USING btree (slug);


--
-- Name: ImagingOrder_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ImagingOrder_tenantId_idx" ON public."ImagingOrder" USING btree ("tenantId");


--
-- Name: ImagingOrder_tenantId_orderNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ImagingOrder_tenantId_orderNumber_key" ON public."ImagingOrder" USING btree ("tenantId", "orderNumber");


--
-- Name: ImagingOrder_tenantId_patientId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ImagingOrder_tenantId_patientId_idx" ON public."ImagingOrder" USING btree ("tenantId", "patientId");


--
-- Name: ImagingOrder_tenantId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ImagingOrder_tenantId_status_idx" ON public."ImagingOrder" USING btree ("tenantId", status);


--
-- Name: ImagingResult_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ImagingResult_tenantId_idx" ON public."ImagingResult" USING btree ("tenantId");


--
-- Name: KioskSession_sessionToken_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "KioskSession_sessionToken_key" ON public."KioskSession" USING btree ("sessionToken");


--
-- Name: KioskSession_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KioskSession_tenantId_idx" ON public."KioskSession" USING btree ("tenantId");


--
-- Name: LabOrder_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "LabOrder_tenantId_idx" ON public."LabOrder" USING btree ("tenantId");


--
-- Name: LabOrder_tenantId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "LabOrder_tenantId_status_idx" ON public."LabOrder" USING btree ("tenantId", status);


--
-- Name: MedicationTransaction_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "MedicationTransaction_tenantId_idx" ON public."MedicationTransaction" USING btree ("tenantId");


--
-- Name: Medication_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Medication_tenantId_idx" ON public."Medication" USING btree ("tenantId");


--
-- Name: Medication_tenantId_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Medication_tenantId_name_idx" ON public."Medication" USING btree ("tenantId", name);


--
-- Name: NHISAuthorization_tenantId_authorizationNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "NHISAuthorization_tenantId_authorizationNumber_key" ON public."NHISAuthorization" USING btree ("tenantId", "authorizationNumber");


--
-- Name: NHISAuthorization_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "NHISAuthorization_tenantId_idx" ON public."NHISAuthorization" USING btree ("tenantId");


--
-- Name: NHISClaim_tenantId_claimNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "NHISClaim_tenantId_claimNumber_key" ON public."NHISClaim" USING btree ("tenantId", "claimNumber");


--
-- Name: NHISClaim_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "NHISClaim_tenantId_idx" ON public."NHISClaim" USING btree ("tenantId");


--
-- Name: NHISDrugFormulary_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "NHISDrugFormulary_tenantId_idx" ON public."NHISDrugFormulary" USING btree ("tenantId");


--
-- Name: NHISDrugFormulary_tenantId_medicationId_nhisCode_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "NHISDrugFormulary_tenantId_medicationId_nhisCode_key" ON public."NHISDrugFormulary" USING btree ("tenantId", "medicationId", "nhisCode");


--
-- Name: NHISDrugFormulary_tenantId_nhisCode_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "NHISDrugFormulary_tenantId_nhisCode_key" ON public."NHISDrugFormulary" USING btree ("tenantId", "nhisCode");


--
-- Name: NHISDrugPrice_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "NHISDrugPrice_tenantId_idx" ON public."NHISDrugPrice" USING btree ("tenantId");


--
-- Name: NHISDrugPrice_tenantId_medicationId_nhisCode_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "NHISDrugPrice_tenantId_medicationId_nhisCode_key" ON public."NHISDrugPrice" USING btree ("tenantId", "medicationId", "nhisCode");


--
-- Name: PartialPayment_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PartialPayment_tenantId_idx" ON public."PartialPayment" USING btree ("tenantId");


--
-- Name: PatientHistoryRecord_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PatientHistoryRecord_tenantId_idx" ON public."PatientHistoryRecord" USING btree ("tenantId");


--
-- Name: PatientJourney_billingRecordId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PatientJourney_billingRecordId_key" ON public."PatientJourney" USING btree ("billingRecordId");


--
-- Name: PatientJourney_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PatientJourney_tenantId_idx" ON public."PatientJourney" USING btree ("tenantId");


--
-- Name: PatientJourney_tenantId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PatientJourney_tenantId_status_idx" ON public."PatientJourney" USING btree ("tenantId", status);


--
-- Name: PatientMessage_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PatientMessage_tenantId_idx" ON public."PatientMessage" USING btree ("tenantId");


--
-- Name: PatientQueue_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PatientQueue_tenantId_idx" ON public."PatientQueue" USING btree ("tenantId");


--
-- Name: PatientQueue_tenantId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PatientQueue_tenantId_status_idx" ON public."PatientQueue" USING btree ("tenantId", status);


--
-- Name: PatientTransfer_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PatientTransfer_tenantId_idx" ON public."PatientTransfer" USING btree ("tenantId");


--
-- Name: PatientTransfer_tenantId_transferNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PatientTransfer_tenantId_transferNumber_key" ON public."PatientTransfer" USING btree ("tenantId", "transferNumber");


--
-- Name: PatientWallet_patientId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PatientWallet_patientId_key" ON public."PatientWallet" USING btree ("patientId");


--
-- Name: PatientWallet_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PatientWallet_tenantId_idx" ON public."PatientWallet" USING btree ("tenantId");


--
-- Name: Patient_tenantId_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Patient_tenantId_email_key" ON public."Patient" USING btree ("tenantId", email);


--
-- Name: Patient_tenantId_fileStatus_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Patient_tenantId_fileStatus_idx" ON public."Patient" USING btree ("tenantId", "fileStatus");


--
-- Name: Patient_tenantId_hospitalId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Patient_tenantId_hospitalId_key" ON public."Patient" USING btree ("tenantId", "hospitalId");


--
-- Name: Patient_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Patient_tenantId_idx" ON public."Patient" USING btree ("tenantId");


--
-- Name: Patient_tenantId_isArchived_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Patient_tenantId_isArchived_idx" ON public."Patient" USING btree ("tenantId", "isArchived");


--
-- Name: Patient_tenantId_isDischarged_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Patient_tenantId_isDischarged_idx" ON public."Patient" USING btree ("tenantId", "isDischarged");


--
-- Name: Patient_walletId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Patient_walletId_key" ON public."Patient" USING btree ("walletId");


--
-- Name: PaymentPlan_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PaymentPlan_tenantId_idx" ON public."PaymentPlan" USING btree ("tenantId");


--
-- Name: PharmacyBranch_tenantId_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PharmacyBranch_tenantId_code_key" ON public."PharmacyBranch" USING btree ("tenantId", code);


--
-- Name: PharmacyBranch_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PharmacyBranch_tenantId_idx" ON public."PharmacyBranch" USING btree ("tenantId");


--
-- Name: PharmacyStaff_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PharmacyStaff_tenantId_idx" ON public."PharmacyStaff" USING btree ("tenantId");


--
-- Name: PharmacyStaff_tenantId_pharmacyId_staffId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PharmacyStaff_tenantId_pharmacyId_staffId_key" ON public."PharmacyStaff" USING btree ("tenantId", "pharmacyId", "staffId");


--
-- Name: PharmacyTransaction_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PharmacyTransaction_tenantId_idx" ON public."PharmacyTransaction" USING btree ("tenantId");


--
-- Name: PharmacyTransaction_tenantId_transactionNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PharmacyTransaction_tenantId_transactionNumber_key" ON public."PharmacyTransaction" USING btree ("tenantId", "transactionNumber");


--
-- Name: Pregnancy_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Pregnancy_tenantId_idx" ON public."Pregnancy" USING btree ("tenantId");


--
-- Name: Prescription_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Prescription_tenantId_idx" ON public."Prescription" USING btree ("tenantId");


--
-- Name: Prescription_tenantId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Prescription_tenantId_status_idx" ON public."Prescription" USING btree ("tenantId", status);


--
-- Name: ROIRequest_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ROIRequest_tenantId_idx" ON public."ROIRequest" USING btree ("tenantId");


--
-- Name: RolePermission_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "RolePermission_tenantId_idx" ON public."RolePermission" USING btree ("tenantId");


--
-- Name: RolePermission_tenantId_role_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "RolePermission_tenantId_role_key" ON public."RolePermission" USING btree ("tenantId", role);


--
-- Name: ServiceConfiguration_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ServiceConfiguration_tenantId_idx" ON public."ServiceConfiguration" USING btree ("tenantId");


--
-- Name: ServiceConfiguration_tenantId_serviceType_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ServiceConfiguration_tenantId_serviceType_key" ON public."ServiceConfiguration" USING btree ("tenantId", "serviceType");


--
-- Name: ServicePrice_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ServicePrice_tenantId_idx" ON public."ServicePrice" USING btree ("tenantId");


--
-- Name: ServicePricing_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ServicePricing_tenantId_idx" ON public."ServicePricing" USING btree ("tenantId");


--
-- Name: ServicePricing_tenantId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ServicePricing_tenantId_name_key" ON public."ServicePricing" USING btree ("tenantId", name);


--
-- Name: StaffClinic_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StaffClinic_tenantId_idx" ON public."StaffClinic" USING btree ("tenantId");


--
-- Name: StaffWard_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StaffWard_tenantId_idx" ON public."StaffWard" USING btree ("tenantId");


--
-- Name: Staff_tenantId_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Staff_tenantId_email_key" ON public."Staff" USING btree ("tenantId", email);


--
-- Name: Staff_tenantId_employeeId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Staff_tenantId_employeeId_key" ON public."Staff" USING btree ("tenantId", "employeeId");


--
-- Name: Staff_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Staff_tenantId_idx" ON public."Staff" USING btree ("tenantId");


--
-- Name: Staff_tenantId_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Staff_tenantId_isActive_idx" ON public."Staff" USING btree ("tenantId", "isActive");


--
-- Name: Staff_tenantId_role_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Staff_tenantId_role_idx" ON public."Staff" USING btree ("tenantId", role);


--
-- Name: Staff_tenantId_username_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Staff_tenantId_username_key" ON public."Staff" USING btree ("tenantId", username);


--
-- Name: VitalSign_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "VitalSign_tenantId_idx" ON public."VitalSign" USING btree ("tenantId");


--
-- Name: VitalSign_tenantId_patientId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "VitalSign_tenantId_patientId_idx" ON public."VitalSign" USING btree ("tenantId", "patientId");


--
-- Name: WalletTransaction_billingRecordId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "WalletTransaction_billingRecordId_key" ON public."WalletTransaction" USING btree ("billingRecordId");


--
-- Name: WalletTransaction_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "WalletTransaction_tenantId_idx" ON public."WalletTransaction" USING btree ("tenantId");


--
-- Name: WalletTransaction_tenantId_paymentReference_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "WalletTransaction_tenantId_paymentReference_key" ON public."WalletTransaction" USING btree ("tenantId", "paymentReference");


--
-- Name: WalletTransaction_tenantId_reference_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "WalletTransaction_tenantId_reference_key" ON public."WalletTransaction" USING btree ("tenantId", reference);


--
-- Name: Ward_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Ward_tenantId_idx" ON public."Ward" USING btree ("tenantId");


--
-- Name: Ward_tenantId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Ward_tenantId_name_key" ON public."Ward" USING btree ("tenantId", name);


--
-- Name: attendance_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "attendance_tenantId_idx" ON public.attendance USING btree ("tenantId");


--
-- Name: dental_records_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "dental_records_tenantId_idx" ON public.dental_records USING btree ("tenantId");


--
-- Name: immunizations_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "immunizations_tenantId_idx" ON public.immunizations USING btree ("tenantId");


--
-- Name: leave_notifications_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "leave_notifications_tenantId_idx" ON public.leave_notifications USING btree ("tenantId");


--
-- Name: leave_policies_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "leave_policies_tenantId_idx" ON public.leave_policies USING btree ("tenantId");


--
-- Name: leave_policies_tenantId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "leave_policies_tenantId_name_key" ON public.leave_policies USING btree ("tenantId", name);


--
-- Name: leave_requests_leave_usage_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX leave_requests_leave_usage_id_key ON public.leave_requests USING btree (leave_usage_id);


--
-- Name: leave_requests_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "leave_requests_tenantId_idx" ON public.leave_requests USING btree ("tenantId");


--
-- Name: leave_usages_leave_request_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX leave_usages_leave_request_id_key ON public.leave_usages USING btree (leave_request_id);


--
-- Name: leave_usages_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "leave_usages_tenantId_idx" ON public.leave_usages USING btree ("tenantId");


--
-- Name: optometry_records_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "optometry_records_tenantId_idx" ON public.optometry_records USING btree ("tenantId");


--
-- Name: patient_notifications_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "patient_notifications_tenantId_idx" ON public.patient_notifications USING btree ("tenantId");


--
-- Name: performance_reviews_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "performance_reviews_tenantId_idx" ON public.performance_reviews USING btree ("tenantId");


--
-- Name: staff_leave_entitlements_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "staff_leave_entitlements_tenantId_idx" ON public.staff_leave_entitlements USING btree ("tenantId");


--
-- Name: staff_leave_entitlements_tenantId_staff_id_year_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "staff_leave_entitlements_tenantId_staff_id_year_key" ON public.staff_leave_entitlements USING btree ("tenantId", staff_id, year);


--
-- Name: staff_trainings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "staff_trainings_tenantId_idx" ON public.staff_trainings USING btree ("tenantId");


--
-- Name: trainings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "trainings_tenantId_idx" ON public.trainings USING btree ("tenantId");


--
-- Name: Admission Admission_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Admission"
    ADD CONSTRAINT "Admission_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Admission Admission_staffId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Admission"
    ADD CONSTRAINT "Admission_staffId_fkey" FOREIGN KEY ("staffId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Admission Admission_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Admission"
    ADD CONSTRAINT "Admission_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Admission Admission_wardId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Admission"
    ADD CONSTRAINT "Admission_wardId_fkey" FOREIGN KEY ("wardId") REFERENCES public."Ward"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AntenatalVisit AntenatalVisit_pregnancyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AntenatalVisit"
    ADD CONSTRAINT "AntenatalVisit_pregnancyId_fkey" FOREIGN KEY ("pregnancyId") REFERENCES public."Pregnancy"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AntenatalVisit AntenatalVisit_staffId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AntenatalVisit"
    ADD CONSTRAINT "AntenatalVisit_staffId_fkey" FOREIGN KEY ("staffId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AntenatalVisit AntenatalVisit_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AntenatalVisit"
    ADD CONSTRAINT "AntenatalVisit_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AppointmentReminder AppointmentReminder_appointmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppointmentReminder"
    ADD CONSTRAINT "AppointmentReminder_appointmentId_fkey" FOREIGN KEY ("appointmentId") REFERENCES public."Appointment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AppointmentReminder AppointmentReminder_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppointmentReminder"
    ADD CONSTRAINT "AppointmentReminder_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Appointment Appointment_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appointment"
    ADD CONSTRAINT "Appointment_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Appointment Appointment_staffId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appointment"
    ADD CONSTRAINT "Appointment_staffId_fkey" FOREIGN KEY ("staffId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Appointment Appointment_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appointment"
    ADD CONSTRAINT "Appointment_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AuditLog AuditLog_staffId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_staffId_fkey" FOREIGN KEY ("staffId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AuditLog AuditLog_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BillingRecord BillingRecord_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BillingRecord"
    ADD CONSTRAINT "BillingRecord_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BillingRecord BillingRecord_processedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BillingRecord"
    ADD CONSTRAINT "BillingRecord_processedBy_fkey" FOREIGN KEY ("processedBy") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: BillingRecord BillingRecord_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BillingRecord"
    ADD CONSTRAINT "BillingRecord_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Clinic Clinic_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Clinic"
    ADD CONSTRAINT "Clinic_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ClinicalNote ClinicalNote_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClinicalNote"
    ADD CONSTRAINT "ClinicalNote_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ClinicalNote ClinicalNote_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClinicalNote"
    ADD CONSTRAINT "ClinicalNote_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ClinicalNote ClinicalNote_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClinicalNote"
    ADD CONSTRAINT "ClinicalNote_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Delivery Delivery_pregnancyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Delivery"
    ADD CONSTRAINT "Delivery_pregnancyId_fkey" FOREIGN KEY ("pregnancyId") REFERENCES public."Pregnancy"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Delivery Delivery_staffId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Delivery"
    ADD CONSTRAINT "Delivery_staffId_fkey" FOREIGN KEY ("staffId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Delivery Delivery_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Delivery"
    ADD CONSTRAINT "Delivery_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Department Department_managerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Department"
    ADD CONSTRAINT "Department_managerId_fkey" FOREIGN KEY ("managerId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Department Department_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Department"
    ADD CONSTRAINT "Department_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: HospitalSettings HospitalSettings_hospitalId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."HospitalSettings"
    ADD CONSTRAINT "HospitalSettings_hospitalId_fkey" FOREIGN KEY ("hospitalId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ImagingOrder ImagingOrder_billingRecordId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ImagingOrder"
    ADD CONSTRAINT "ImagingOrder_billingRecordId_fkey" FOREIGN KEY ("billingRecordId") REFERENCES public."BillingRecord"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ImagingOrder ImagingOrder_orderingStaffId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ImagingOrder"
    ADD CONSTRAINT "ImagingOrder_orderingStaffId_fkey" FOREIGN KEY ("orderingStaffId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ImagingOrder ImagingOrder_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ImagingOrder"
    ADD CONSTRAINT "ImagingOrder_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ImagingOrder ImagingOrder_radiologistId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ImagingOrder"
    ADD CONSTRAINT "ImagingOrder_radiologistId_fkey" FOREIGN KEY ("radiologistId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ImagingOrder ImagingOrder_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ImagingOrder"
    ADD CONSTRAINT "ImagingOrder_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ImagingResult ImagingResult_imagingOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ImagingResult"
    ADD CONSTRAINT "ImagingResult_imagingOrderId_fkey" FOREIGN KEY ("imagingOrderId") REFERENCES public."ImagingOrder"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ImagingResult ImagingResult_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ImagingResult"
    ADD CONSTRAINT "ImagingResult_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: KioskSession KioskSession_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KioskSession"
    ADD CONSTRAINT "KioskSession_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: KioskSession KioskSession_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KioskSession"
    ADD CONSTRAINT "KioskSession_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: LabOrder LabOrder_labStaffId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LabOrder"
    ADD CONSTRAINT "LabOrder_labStaffId_fkey" FOREIGN KEY ("labStaffId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: LabOrder LabOrder_orderingStaffId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LabOrder"
    ADD CONSTRAINT "LabOrder_orderingStaffId_fkey" FOREIGN KEY ("orderingStaffId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: LabOrder LabOrder_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LabOrder"
    ADD CONSTRAINT "LabOrder_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: LabOrder LabOrder_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LabOrder"
    ADD CONSTRAINT "LabOrder_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MedicationTransaction MedicationTransaction_medicationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MedicationTransaction"
    ADD CONSTRAINT "MedicationTransaction_medicationId_fkey" FOREIGN KEY ("medicationId") REFERENCES public."Medication"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MedicationTransaction MedicationTransaction_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MedicationTransaction"
    ADD CONSTRAINT "MedicationTransaction_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MedicationTransaction MedicationTransaction_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MedicationTransaction"
    ADD CONSTRAINT "MedicationTransaction_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Medication Medication_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Medication"
    ADD CONSTRAINT "Medication_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: NHISAuthorization NHISAuthorization_approvedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NHISAuthorization"
    ADD CONSTRAINT "NHISAuthorization_approvedBy_fkey" FOREIGN KEY ("approvedBy") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: NHISAuthorization NHISAuthorization_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NHISAuthorization"
    ADD CONSTRAINT "NHISAuthorization_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NHISAuthorization NHISAuthorization_prescriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NHISAuthorization"
    ADD CONSTRAINT "NHISAuthorization_prescriptionId_fkey" FOREIGN KEY ("prescriptionId") REFERENCES public."Prescription"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: NHISAuthorization NHISAuthorization_requestedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NHISAuthorization"
    ADD CONSTRAINT "NHISAuthorization_requestedBy_fkey" FOREIGN KEY ("requestedBy") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NHISAuthorization NHISAuthorization_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NHISAuthorization"
    ADD CONSTRAINT "NHISAuthorization_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: NHISClaim NHISClaim_approvedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NHISClaim"
    ADD CONSTRAINT "NHISClaim_approvedBy_fkey" FOREIGN KEY ("approvedBy") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: NHISClaim NHISClaim_authorizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NHISClaim"
    ADD CONSTRAINT "NHISClaim_authorizationId_fkey" FOREIGN KEY ("authorizationId") REFERENCES public."NHISAuthorization"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: NHISClaim NHISClaim_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NHISClaim"
    ADD CONSTRAINT "NHISClaim_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NHISClaim NHISClaim_prescriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NHISClaim"
    ADD CONSTRAINT "NHISClaim_prescriptionId_fkey" FOREIGN KEY ("prescriptionId") REFERENCES public."Prescription"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: NHISClaim NHISClaim_submittedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NHISClaim"
    ADD CONSTRAINT "NHISClaim_submittedBy_fkey" FOREIGN KEY ("submittedBy") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NHISClaim NHISClaim_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NHISClaim"
    ADD CONSTRAINT "NHISClaim_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: NHISDrugFormulary NHISDrugFormulary_medicationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NHISDrugFormulary"
    ADD CONSTRAINT "NHISDrugFormulary_medicationId_fkey" FOREIGN KEY ("medicationId") REFERENCES public."Medication"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NHISDrugFormulary NHISDrugFormulary_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NHISDrugFormulary"
    ADD CONSTRAINT "NHISDrugFormulary_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: NHISDrugPrice NHISDrugPrice_medicationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NHISDrugPrice"
    ADD CONSTRAINT "NHISDrugPrice_medicationId_fkey" FOREIGN KEY ("medicationId") REFERENCES public."Medication"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NHISDrugPrice NHISDrugPrice_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NHISDrugPrice"
    ADD CONSTRAINT "NHISDrugPrice_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PartialPayment PartialPayment_paymentPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PartialPayment"
    ADD CONSTRAINT "PartialPayment_paymentPlanId_fkey" FOREIGN KEY ("paymentPlanId") REFERENCES public."PaymentPlan"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PartialPayment PartialPayment_processedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PartialPayment"
    ADD CONSTRAINT "PartialPayment_processedBy_fkey" FOREIGN KEY ("processedBy") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PartialPayment PartialPayment_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PartialPayment"
    ADD CONSTRAINT "PartialPayment_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PatientHistoryRecord PatientHistoryRecord_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientHistoryRecord"
    ADD CONSTRAINT "PatientHistoryRecord_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PatientHistoryRecord PatientHistoryRecord_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientHistoryRecord"
    ADD CONSTRAINT "PatientHistoryRecord_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PatientJourney PatientJourney_billingRecordId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientJourney"
    ADD CONSTRAINT "PatientJourney_billingRecordId_fkey" FOREIGN KEY ("billingRecordId") REFERENCES public."BillingRecord"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PatientJourney PatientJourney_clinicId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientJourney"
    ADD CONSTRAINT "PatientJourney_clinicId_fkey" FOREIGN KEY ("clinicId") REFERENCES public."Clinic"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PatientJourney PatientJourney_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientJourney"
    ADD CONSTRAINT "PatientJourney_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PatientJourney PatientJourney_registeredById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientJourney"
    ADD CONSTRAINT "PatientJourney_registeredById_fkey" FOREIGN KEY ("registeredById") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PatientJourney PatientJourney_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientJourney"
    ADD CONSTRAINT "PatientJourney_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PatientJourney PatientJourney_wardId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientJourney"
    ADD CONSTRAINT "PatientJourney_wardId_fkey" FOREIGN KEY ("wardId") REFERENCES public."Ward"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PatientMessage PatientMessage_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientMessage"
    ADD CONSTRAINT "PatientMessage_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PatientMessage PatientMessage_staffId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientMessage"
    ADD CONSTRAINT "PatientMessage_staffId_fkey" FOREIGN KEY ("staffId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PatientMessage PatientMessage_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientMessage"
    ADD CONSTRAINT "PatientMessage_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PatientQueue PatientQueue_appointmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientQueue"
    ADD CONSTRAINT "PatientQueue_appointmentId_fkey" FOREIGN KEY ("appointmentId") REFERENCES public."Appointment"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PatientQueue PatientQueue_assignedTo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientQueue"
    ADD CONSTRAINT "PatientQueue_assignedTo_fkey" FOREIGN KEY ("assignedTo") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PatientQueue PatientQueue_clinicId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientQueue"
    ADD CONSTRAINT "PatientQueue_clinicId_fkey" FOREIGN KEY ("clinicId") REFERENCES public."Clinic"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PatientQueue PatientQueue_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientQueue"
    ADD CONSTRAINT "PatientQueue_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PatientQueue PatientQueue_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientQueue"
    ADD CONSTRAINT "PatientQueue_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PatientQueue PatientQueue_wardId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientQueue"
    ADD CONSTRAINT "PatientQueue_wardId_fkey" FOREIGN KEY ("wardId") REFERENCES public."Ward"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PatientTransfer PatientTransfer_approvedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientTransfer"
    ADD CONSTRAINT "PatientTransfer_approvedBy_fkey" FOREIGN KEY ("approvedBy") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PatientTransfer PatientTransfer_fromClinicId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientTransfer"
    ADD CONSTRAINT "PatientTransfer_fromClinicId_fkey" FOREIGN KEY ("fromClinicId") REFERENCES public."Clinic"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PatientTransfer PatientTransfer_fromWardId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientTransfer"
    ADD CONSTRAINT "PatientTransfer_fromWardId_fkey" FOREIGN KEY ("fromWardId") REFERENCES public."Ward"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PatientTransfer PatientTransfer_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientTransfer"
    ADD CONSTRAINT "PatientTransfer_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PatientTransfer PatientTransfer_requestedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientTransfer"
    ADD CONSTRAINT "PatientTransfer_requestedBy_fkey" FOREIGN KEY ("requestedBy") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PatientTransfer PatientTransfer_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientTransfer"
    ADD CONSTRAINT "PatientTransfer_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PatientTransfer PatientTransfer_toClinicId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientTransfer"
    ADD CONSTRAINT "PatientTransfer_toClinicId_fkey" FOREIGN KEY ("toClinicId") REFERENCES public."Clinic"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PatientTransfer PatientTransfer_toWardId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientTransfer"
    ADD CONSTRAINT "PatientTransfer_toWardId_fkey" FOREIGN KEY ("toWardId") REFERENCES public."Ward"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PatientWallet PatientWallet_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientWallet"
    ADD CONSTRAINT "PatientWallet_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PatientWallet PatientWallet_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PatientWallet"
    ADD CONSTRAINT "PatientWallet_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Patient Patient_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Patient"
    ADD CONSTRAINT "Patient_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PaymentPlan PaymentPlan_billingRecordId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentPlan"
    ADD CONSTRAINT "PaymentPlan_billingRecordId_fkey" FOREIGN KEY ("billingRecordId") REFERENCES public."BillingRecord"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PaymentPlan PaymentPlan_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentPlan"
    ADD CONSTRAINT "PaymentPlan_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PaymentPlan PaymentPlan_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentPlan"
    ADD CONSTRAINT "PaymentPlan_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PharmacyBranch PharmacyBranch_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PharmacyBranch"
    ADD CONSTRAINT "PharmacyBranch_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PharmacyStaff PharmacyStaff_pharmacyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PharmacyStaff"
    ADD CONSTRAINT "PharmacyStaff_pharmacyId_fkey" FOREIGN KEY ("pharmacyId") REFERENCES public."PharmacyBranch"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PharmacyStaff PharmacyStaff_staffId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PharmacyStaff"
    ADD CONSTRAINT "PharmacyStaff_staffId_fkey" FOREIGN KEY ("staffId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PharmacyStaff PharmacyStaff_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PharmacyStaff"
    ADD CONSTRAINT "PharmacyStaff_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PharmacyTransaction PharmacyTransaction_medicationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PharmacyTransaction"
    ADD CONSTRAINT "PharmacyTransaction_medicationId_fkey" FOREIGN KEY ("medicationId") REFERENCES public."Medication"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PharmacyTransaction PharmacyTransaction_pharmacyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PharmacyTransaction"
    ADD CONSTRAINT "PharmacyTransaction_pharmacyId_fkey" FOREIGN KEY ("pharmacyId") REFERENCES public."PharmacyBranch"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PharmacyTransaction PharmacyTransaction_staffId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PharmacyTransaction"
    ADD CONSTRAINT "PharmacyTransaction_staffId_fkey" FOREIGN KEY ("staffId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PharmacyTransaction PharmacyTransaction_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PharmacyTransaction"
    ADD CONSTRAINT "PharmacyTransaction_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Pregnancy Pregnancy_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pregnancy"
    ADD CONSTRAINT "Pregnancy_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Pregnancy Pregnancy_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pregnancy"
    ADD CONSTRAINT "Pregnancy_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Prescription Prescription_dispensingStaffId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Prescription"
    ADD CONSTRAINT "Prescription_dispensingStaffId_fkey" FOREIGN KEY ("dispensingStaffId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Prescription Prescription_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Prescription"
    ADD CONSTRAINT "Prescription_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Prescription Prescription_prescribingStaffId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Prescription"
    ADD CONSTRAINT "Prescription_prescribingStaffId_fkey" FOREIGN KEY ("prescribingStaffId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Prescription Prescription_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Prescription"
    ADD CONSTRAINT "Prescription_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ROIRequest ROIRequest_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ROIRequest"
    ADD CONSTRAINT "ROIRequest_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: RolePermission RolePermission_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServiceConfiguration ServiceConfiguration_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceConfiguration"
    ADD CONSTRAINT "ServiceConfiguration_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServicePrice ServicePrice_clinicId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServicePrice"
    ADD CONSTRAINT "ServicePrice_clinicId_fkey" FOREIGN KEY ("clinicId") REFERENCES public."Clinic"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ServicePrice ServicePrice_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServicePrice"
    ADD CONSTRAINT "ServicePrice_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServicePricing ServicePricing_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServicePricing"
    ADD CONSTRAINT "ServicePricing_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StaffClinic StaffClinic_clinicId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StaffClinic"
    ADD CONSTRAINT "StaffClinic_clinicId_fkey" FOREIGN KEY ("clinicId") REFERENCES public."Clinic"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StaffClinic StaffClinic_staffId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StaffClinic"
    ADD CONSTRAINT "StaffClinic_staffId_fkey" FOREIGN KEY ("staffId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StaffClinic StaffClinic_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StaffClinic"
    ADD CONSTRAINT "StaffClinic_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StaffWard StaffWard_staffId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StaffWard"
    ADD CONSTRAINT "StaffWard_staffId_fkey" FOREIGN KEY ("staffId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StaffWard StaffWard_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StaffWard"
    ADD CONSTRAINT "StaffWard_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StaffWard StaffWard_wardId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StaffWard"
    ADD CONSTRAINT "StaffWard_wardId_fkey" FOREIGN KEY ("wardId") REFERENCES public."Ward"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Staff Staff_departmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Staff"
    ADD CONSTRAINT "Staff_departmentId_fkey" FOREIGN KEY ("departmentId") REFERENCES public."Department"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Staff Staff_manager_id_fkey_self; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Staff"
    ADD CONSTRAINT "Staff_manager_id_fkey_self" FOREIGN KEY (manager_id) REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Staff Staff_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Staff"
    ADD CONSTRAINT "Staff_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: VitalSign VitalSign_nurseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VitalSign"
    ADD CONSTRAINT "VitalSign_nurseId_fkey" FOREIGN KEY ("nurseId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: VitalSign VitalSign_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VitalSign"
    ADD CONSTRAINT "VitalSign_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: VitalSign VitalSign_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VitalSign"
    ADD CONSTRAINT "VitalSign_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WalletTransaction WalletTransaction_billingRecordId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WalletTransaction"
    ADD CONSTRAINT "WalletTransaction_billingRecordId_fkey" FOREIGN KEY ("billingRecordId") REFERENCES public."BillingRecord"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: WalletTransaction WalletTransaction_paidToStaffId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WalletTransaction"
    ADD CONSTRAINT "WalletTransaction_paidToStaffId_fkey" FOREIGN KEY ("paidToStaffId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: WalletTransaction WalletTransaction_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WalletTransaction"
    ADD CONSTRAINT "WalletTransaction_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WalletTransaction WalletTransaction_walletId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WalletTransaction"
    ADD CONSTRAINT "WalletTransaction_walletId_fkey" FOREIGN KEY ("walletId") REFERENCES public."PatientWallet"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Ward Ward_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ward"
    ADD CONSTRAINT "Ward_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: attendance attendance_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: attendance attendance_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT "attendance_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dental_records dental_records_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dental_records
    ADD CONSTRAINT "dental_records_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dental_records dental_records_staffId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dental_records
    ADD CONSTRAINT "dental_records_staffId_fkey" FOREIGN KEY ("staffId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: dental_records dental_records_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dental_records
    ADD CONSTRAINT "dental_records_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: immunizations immunizations_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.immunizations
    ADD CONSTRAINT "immunizations_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: immunizations immunizations_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.immunizations
    ADD CONSTRAINT "immunizations_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: leave_notifications leave_notifications_leave_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_notifications
    ADD CONSTRAINT leave_notifications_leave_request_id_fkey FOREIGN KEY (leave_request_id) REFERENCES public.leave_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: leave_notifications leave_notifications_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_notifications
    ADD CONSTRAINT leave_notifications_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: leave_notifications leave_notifications_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_notifications
    ADD CONSTRAINT "leave_notifications_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: leave_policies leave_policies_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_policies
    ADD CONSTRAINT "leave_policies_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: leave_requests leave_requests_approved_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_approved_by_id_fkey FOREIGN KEY (approved_by_id) REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: leave_requests leave_requests_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: leave_requests leave_requests_substitute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_substitute_id_fkey FOREIGN KEY (substitute_id) REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: leave_requests leave_requests_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT "leave_requests_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: leave_usages leave_usages_approved_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_usages
    ADD CONSTRAINT leave_usages_approved_by_id_fkey FOREIGN KEY (approved_by_id) REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: leave_usages leave_usages_entitlement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_usages
    ADD CONSTRAINT leave_usages_entitlement_id_fkey FOREIGN KEY (entitlement_id) REFERENCES public.staff_leave_entitlements(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: leave_usages leave_usages_leave_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_usages
    ADD CONSTRAINT leave_usages_leave_request_id_fkey FOREIGN KEY (leave_request_id) REFERENCES public.leave_requests(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: leave_usages leave_usages_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_usages
    ADD CONSTRAINT leave_usages_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: leave_usages leave_usages_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_usages
    ADD CONSTRAINT "leave_usages_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: optometry_records optometry_records_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optometry_records
    ADD CONSTRAINT "optometry_records_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: optometry_records optometry_records_staffId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optometry_records
    ADD CONSTRAINT "optometry_records_staffId_fkey" FOREIGN KEY ("staffId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: optometry_records optometry_records_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optometry_records
    ADD CONSTRAINT "optometry_records_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: patient_notifications patient_notifications_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_notifications
    ADD CONSTRAINT "patient_notifications_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: patient_notifications patient_notifications_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_notifications
    ADD CONSTRAINT "patient_notifications_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: performance_reviews performance_reviews_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.performance_reviews
    ADD CONSTRAINT performance_reviews_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: performance_reviews performance_reviews_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.performance_reviews
    ADD CONSTRAINT performance_reviews_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: performance_reviews performance_reviews_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.performance_reviews
    ADD CONSTRAINT "performance_reviews_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: staff_leave_entitlements staff_leave_entitlements_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_leave_entitlements
    ADD CONSTRAINT staff_leave_entitlements_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: staff_leave_entitlements staff_leave_entitlements_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_leave_entitlements
    ADD CONSTRAINT "staff_leave_entitlements_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: staff_trainings staff_trainings_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_trainings
    ADD CONSTRAINT staff_trainings_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: staff_trainings staff_trainings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_trainings
    ADD CONSTRAINT "staff_trainings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: staff_trainings staff_trainings_training_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_trainings
    ADD CONSTRAINT staff_trainings_training_id_fkey FOREIGN KEY (training_id) REFERENCES public.trainings(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: trainings trainings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trainings
    ADD CONSTRAINT "trainings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Hospital"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict 08BbhOvw5Xsj4s0GVAZZWk18UUgUsYEnVsI9l29LMe7bD4tfWGKMNfOWJ1vZZOj

